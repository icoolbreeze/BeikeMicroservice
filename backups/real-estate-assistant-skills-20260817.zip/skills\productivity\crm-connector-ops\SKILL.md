---
name: crm-connector-ops
description: "Use when CRM auth fails, listing photos need combining, or browser credential injection is needed to visit the CRM site (lease-pz/house workbench)."
version: 1.1.0
author: hermes-curator
license: proprietary
metadata:
  hermes:
    tags: [crm, beike, lianjia, auth, images]
    related_skills: [rental-search, sale-search]
---

# CRM connector operations

## When to Use

- CRM MCP tools error with `business session produced no business cookies` or `MCP server ... unreachable` after a session lapse.
- The user asks to combine listing photos (房源图片) into one image / contact sheet.
- You need to restart or verify the local CRM connector services (8020 uvicorn, MCP bridge).

Operating the local KeCom CRM connector (Hermes currently registers tools as `mcp__crm_connector__*`; after restarting the MCP child verify with `mcp__crm_connector__crm_connection_status`). Connector source at `C:/Users/shipi/vswp/BeikeMicroservice/services/crm_connector`. Complements the rental-search / sale-search skills (search semantics); this skill covers keeping the connector alive and rendering its images.

## Topology — who holds what

- **MCP server process**: gateway child, cmdline `C:/ProgramData/miniconda3/python.exe -m app.mcp.server`, built via `app.bootstrap.build_service`. Has its OWN SessionProvider + in-memory cookie jar — shares NO runtime state with the main service. Started (and auto-restarted on death) by the hermes gateway.
- **Main service**: `uvicorn app.main:create_app --factory --host 127.0.0.1 --port 8020` (run from connector dir). Exposes HTTP API incl. `/api/v1/connection/status`; runs a session watchdog (~60 s ticks). Independently loads the credential store and can auto-refresh its session at startup.
- **Credential store**: `run/credential_store.bin`, Windows DPAPI-encrypted, 1 h local expiry estimate + refresh_material (TGC). Managed by `crm-authd`.

## PYTHONPATH pitfall (hit every time you shell out)

The bash environment inherits `PYTHONPATH=C:\Users\shipi\AppData\Local\hermes\hermes-agent;...\venv\Lib\site-packages`, so miniconda python loads hermes venv pydantic → `ModuleNotFoundError: No module named 'pydantic_core._pydantic_core'`. ALWAYS run connector python as:
`env -u PYTHONPATH C:/ProgramData/miniconda3/python.exe ...`
The gateway-spawned MCP process is unaffected (clean env), only shell invocations are.

**Same pollution hits C:\Python313** (playwright renderer for listing_poster/listing_detail_poster): hermes venv's PIL is broken (`ImportError: cannot import name '_imaging' from 'PIL'`), so any PIL-using code (pixel sampling, pytest fixtures) run as `env -u PYTHONPATH C:/Python313/python.exe ...`. Pure playwright rendering is fine under plain `/c/Python313/python.exe`; only PIL imports need the strip.

## Browser credential injection (凭证注入打开真实 CRM 站点) — verified 2026-08-13

Goal: open the real CRM web UI (租赁工作台) in a browser with the connector's session. The ONLY working method is Playwright `context.add_cookies` (or CDP `Network.setCookie`) — `document.cookie` injection FAILS (can't set HttpOnly, and the Hermes browser console rejects `domain=` attributes silently; also its console falls back to `about:blank` after redirects).

Workflow (one-shot temp script, delete afterwards):

1. Decode the DPAPI credential store — no running service needed (same source the MCP process bootstraps from):
   `env -u PYTHONPATH C:/ProgramData/miniconda3/python.exe` with `WindowsDpapiCredentialStore(settings.credential_store_path).load_active()` → `_decode_material(active.credential_material)` → dict of cookies.
2. Inject with Playwright: `context.add_cookies([...])` for EVERY cookie with `domain=".link.lianjia.com"`, `path="/"`, `httpOnly=True`, `secure=True`, `sameSite="Lax"`, `expires=-1`. Call `ctx.clear_cookies()` FIRST (stale domain cookies otherwise shadow the injected ones). `.link.lianjia.com` covers both `lease-pz` and `house` subdomains.
3. Navigate `https://lease-pz.link.lianjia.com/rent/house/list?isSaaS=false`, `wait_until="domcontentloaded"`, then `page.wait_for_timeout(6000)` for the SPA render.
4. Success = ALL of: final URL has no `login.ke.com`; title contains `房源列表` + `普租`; body contains `万世平`; nav words `房源`/`客源`/`线索`; body contains `商圈` + `维护盘房源`.

### DOM-first page analysis (user preference, verified 2026-08-13)

用户要求页面分析尽量走 DOM 理解，理解不了再截图。一次性学习用 headless 脚本：注入 cookies → `goto(wait_until="domcontentloaded")` → `time.sleep(8)` 等 SPA 渲染 → `page.evaluate` 提取 title / 最终 URL / 导航词 / 筛选组标签 / `body.innerText` 头部 → 写 dump 文件 → `browser.close()`（加载 `run/browser_state.json`，用后删除脚本）。headless 下租赁列表页可正常渲染（title=房源列表 - 普租，筛选条完整可读）。页面结构详见 `references/rental-workbench-dom.md`。向用户汇报时先给 DOM 文本结论，仅当 DOM 无法解析布局时才截图（`full_page=True`）。
5. If FAILED → do NOT retry injection. The store material is stale (the MCP process's keepalive rotates sessions; store can lag). Trigger re-login: `curl -X POST http://127.0.0.1:8020/api/v1/auth/login` → native Tk QR window for the user to scan, then re-run from step 1.
6. Cleanup: delete the temp script + temp cookie JSON. NEVER print cookie values in logs or chat.

Known dead ends (don't repeat):
- `https://house.link.lianjia.com/ershoufang/` is a 404 shell (德佑-房源 → 对不起，您输入的地址有误) — NOT the 买卖 workbench entry. Use MCP `sale_*` tools for 买卖 data instead of guessing house-domain UI URLs.
- ke.com CAS hop: TGC/TGC_Secure/security_ticket (from `run/house_browser_cookies.json`) only reaches 选择账号类型; 员工 login still requires QR scan or password — no cookie-only path.
- `house.link.lianjia.com` (买卖房源详情) needs a shiro-cas hop (`run/hop_house_session.py`): HOUSEJSESSIONID is HttpOnly and host-scoped to `house.`. For lease-pz browsing the .link.lianjia.com injection above is sufficient.
- Anti-automation: pages use `debugger` statements — with Playwright register CDP `Debugger.setSkipAllPauses` per page (see `run/open_browser.py` `_harden`).

## Session recovery (business cookies missing)

Symptom: MCP tools error `business session produced no business cookies (business=['lianjia_ssid','lianjia_uuid','login_ucid'] ...)` while `crm-authd status` says `ready`. Local `ready` only means the DPAPI record exists — upstream can still be rejected (main-service log shows `502` on `/api/v1/crm/me`). Recovery:

1. Check credential: `cd services/crm_connector && env -u PYTHONPATH C:/ProgramData/miniconda3/python.exe -m app.authd.cli status`
2. Trigger QR login (background=true): `env -u PYTHONPATH C:/ProgramData/miniconda3/python.exe -m app.authd.cli login`
   - Pops a NATIVE Windows Tk QR window on the user's desktop; the user scans with the 链家/贝壳 phone app. Blocks until confirmed. Success marker in log: `post_business_session` cookie jar containing `puzu_lease_token`, `saas_token`, `lianjia_ssid`.
3. Restart BOTH processes so they load the fresh credential:
   - **Main service**: `taskkill /PID <uvicorn-pid> /F`, then relaunch the uvicorn command (background, watch "Application startup complete"). It re-bootstraps its session on startup.
   - **MCP process**: find with `tasklist` (gateway child running `-m app.mcp.server`), `taskkill /PID <pid> /F` — the gateway auto-restarts it. Without this step MCP tools keep failing with the stale session.
4. Verify: `curl http://127.0.0.1:8020/api/v1/connection/status` → `{"state":"ready",...}` with fresh `credential_expires_at`; then retry the MCP tool.

## Degraded latch — CRM_AUTH_REQUIRED / CRM_CONNECTOR_DEGRADED（凭证其实有效）— verified 2026-08-14

Symptom: MCP tools fail instantly (0.00s) with `CRM_AUTH_REQUIRED: ... rejected by the upstream after request` or `CRM_CONNECTOR_DEGRADED: upstream rejected credential; refresh attempted`; `crm_connection_status` → `state: degraded`, `bound_employee_principal: null`, but `credential_expires_at` is still in the future (user will rightly insist 认证没过期).

Root cause: `kecom_session_provider._deactivate_locked(..., "upstream_rejected")` sets a process-internal `_degraded_message` latch after ONE upstream 401/403 + failed TGC refresh. The latch persists until a successful keepalive/login; every subsequent call short-circuits WITHOUT touching the network. The stored credential can be perfectly valid.

Verify the credential BEFORE touching auth (DPAPI decode needs win32crypt — miniconda base LACKS it, use `C:/ProgramData/miniconda3/envs/openwebui/python.exe`):
1. `WindowsDpapiCredentialStore(settings.credential_store_path).load_active()` → `_decode_material()` → cookie dict.
2. GET `{origin}/rent/house/list?isSaaS=false` with `_select_cookies(cookies)` → HTTP 200 HTML = valid.
3. GET `{origin}/api/puzuHouse/puzu/house/auth/pc/accountRightInfo?typeList=2` (keepalive probe; same cookies + `x-requested-with: XMLHttpRequest` + referer headers) → `code:100000` = valid.
Both 200 ⇒ the credential is NOT the problem — do not re-login.

Fix WITHOUT QR re-scan: kill ALL gateway children `python.exe -m app.mcp.server` (`taskkill /PID <pid> /F` — find via PowerShell `Get-CimInstance Win32_Process | Where-Object {$_.CommandLine -match "app.mcp.server" -and $_.CommandLine -notmatch "powershell|bash"}`); the gateway auto-restarts them in ~50 s. The fresh process re-loads the store and re-validates: `crm_connection_status` → `ready`, tools work again.

Shell notes: PowerShell from git-bash — `$_` gets bash-expanded inside double quotes; single-quote the whole PowerShell command. `taskkill` needs `/PID` (not `//PID` — MSYS path mangling).

## Stdio-only auth_required — 8020 HTTP 备援通道（2026-08-17 实测）

Symptom: `crm_connection_status` → `state: auth_required`，message `CRM authorization expired; refresh failed, rescan required`（重连后变 `not bootstrapped`），但 8020 主服务会话正常（session_watchdog `state=ready`、日志有成功的 `session.refresh_via_tgc`、业务请求 200）。

与 degraded latch 的区别：stdio MCP 进程与 8020 主服务对凭证状态判断不一致，此时**杀 `app.mcp.server` 重连无效**（重启后仍 not bootstrapped）——不要照搬 2026-08-14 的杀进程修复。

判定与应对：
1. **探针**：`curl -s -X POST http://127.0.0.1:8020/api/v1/auth/login`
   - 409 `CRM_QR_LOGIN_CONFLICT`（"already authenticated"）→ 8020 凭证有效，坏的只是 stdio 进程。杀子进程重连后若仍 not bootstrapped，**直接用 8020 HTTP 通道查询，不阻塞任务**。
   - 返回 `login_id`+`qrcode` → 凭证真过期：`curl -o qr.png http://127.0.0.1:8020/api/v1/auth/login/<login_id>/qrcode.png` 拿二维码图给用户扫，轮询 `GET /api/v1/auth/login/<login_id>` 至 ready。
2. **HTTP 查询端点**（与 MCP 工具同语义；请求 schema 在 `services/crm_connector/app/api/schemas.py`，如 `RentalMapNearbySearchRequest`）：
   - `POST /api/v1/listings/rental/map/nearby`（location / radius_meters / price_min_yuan / price_max_yuan / rooms / rental_modes / page）
   - `POST /api/v1/listings/rental/map/suggest`、`POST /api/v1/listings/rental/search`、`GET /api/v1/listings/rental/{id}`、`/{id}/prospect`、`/{id}/house-info`、`/{id}/redirect`；买卖同构 `/api/v1/listings/sale/...`
   - 错误语义与 MCP 相同：实测 `新华公园` 触发 `map location could not be resolved to coordinates` → 仍走 rental-search 的中心点解析回退链（Baidu POI → CRM suggest）。

## Listing image download (img.ljcdn.com)

- **Scaled (watermarked) variants are PUBLIC — no cookies needed.** Append one of the connector's canonical public size suffixes to the FULL original path, keeping the original extension: `xxx.jpg` → `xxx.jpg.750x.jpg`. Canonical sizes are `.450x.jpg` / `.750x.jpg` / `.800x.jpg` / `.1500x.jpg`. Works for `110000-inspection` (实勘照), `hdic-frame` (户型图), and `lease-image` buckets. Returns 200 + real JPEG (watermark comment "来自贝壳/链家网, 版权所有, 盗版必究").
- **Strip broken directives first**: CRM `surface_image_url` / `floor_plan_image_url` may carry a `!`-directive suffix (e.g. `...jpg!m_fill,l_dy`). That directive is malformed (missing width/height → HTTP 400 "command 'width' or 'height' is required"). Remove everything from `!` onward, then append the scaled suffix.
- **Raw/original (watermark-free) variants DO need cookies**: bare URL without a scaled suffix → 403 (`m_original` command not authorized). Use `run/live_cookies.json` (JSON list of `{name,value}`; stays valid for the CDN even after a re-login). Send as `Cookie: name=value; ...` header. This is only needed when the user wants unwatermarked originals (e.g. 拿原图无水印), which is rarely requested — default to the public scaled variant.
- Relative URLs (`/hdic-frame/...`) need the `https://img.ljcdn.com` prefix. Treat <500-byte responses and 404 as "no image".

## Rental prospect 实勘照片接口（2026-08-14 源码确认+实测）

`rental_listing_get_prospect`（HTTP 同款：`GET /api/v1/listings/rental/{listing_id}/prospect`）返回全屋实勘：`photos[] = {url, room_name(客厅/卧室/厨房/卫生间), image_type(TITLE=封面/REAL=实勘), upload_user, created_at}` + `floor_plan_url`（户型图，可能为相对路径，需补 `https://img.ljcdn.com` 前缀）。

**关键域限制**：prospect 只服务**普租（delType=2）**房源——**托管（delType=5）在普租 prospect 域返回空**（`houseProspectImageList` 空；源码注释"托管不在普租详情域"）。因此：
- 列表筛选 `prospect=1`（有实勘标记）**不等于** prospect 接口有照片（托管房也带标记但接口仍空）——用户说"租赁房源大多实勘都可以查看"即指普租。
- 高效找有全屋实勘的候选池：`condition_filters={"delType":"2","prospect":"1"}` 双条件齐筛。
- 遇空 photos：先看 del_type——托管房源不能据此判断无实勘，必须改走 `tuoguan_listing_get_detail(cell_code)`；cell_code 主路径用 `GET /api/v1/listings/rental/{listing_id}/redirect`（连接器封装的前端点击链路 getRedirectUrl），再用详情返回的 `house_del_code` 回链校验；校验失败应停止推荐，不得用封面图冒充全屋实勘。

## Contact sheet (房源图片拼图) workflow

- **v3 (推荐编号拼图，2026-08-14 定稿，推荐交付标准)**：脚本在 `listing-poster` 技能目录 `C:\Users\shipi\AppData\Local\hermes\skills\productivity\listing-poster\scripts\listing_poster.py`（HTML/CSS + Playwright 无头渲染，**dark 主题**）。详见 `listing-poster` 技能。要点：items 直接塞 MCP 原始行自动归一化（租赁/买卖/地图三种形态）；3 列卡片；图片自动拼 `.750x.jpg` 公开后缀下载（无需 cookie）；左上角编号角标（用户报号）；评分徽章色阶内置（≥88 推荐/≥78 考虑）。**运行解释器必须用 `C:/Python313/python.exe`（有 playwright），Hermes venv 无 playwright**。用法：
  `cd C:/Users/shipi/AppData/Local/hermes/skills/productivity/listing-poster && /c/Python313/python.exe scripts/listing_poster.py <payload.json> --theme dark`
- **v2.1 (旧推荐模板，2026-08-14 起不再用于推荐交付)**：`templates/make_recommend_sheet.py` — 3 列卡片网格，左上角大号圆形编号徽章，评分环；保留备用（仅当 v3 环境不可用时回退）。data.json = `[{no, price, layout, area, orient, community, tags, score, level, title_url, floor_url}, ...]`（no 省略自动 1..n）
- **v1 (简单联系表)**：`templates/make_listing_sheet.py` — 4 列网格、单行标签（价格/户型/面积/朝向），仅适合快速浏览。

Note: `vision_analyze` cannot verify the sheet on this setup (provider rejects image input) — rely on PIL success + non-empty downloads instead.

## Pitfalls

- Never invent community ids / cookie values; the search skills' rules still apply.
- `crm-authd logout` revokes upstream + clears the local record — only use deliberately.
- The 8020 uvicorn is a separate long-lived process from the MCP bridge; restarting one does NOT refresh the other.
