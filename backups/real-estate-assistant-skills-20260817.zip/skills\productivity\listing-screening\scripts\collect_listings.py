#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""批量采集成都买卖/租赁房源列表（HTTP 8020，模拟人工节奏）。
用法: python collect_listings.py
输出: ~/listing_analysis/sale_listings.json, rental_listings.json
注意: 租赁价格段必须用 condition_filters.price（monthly_rent_yuan 会被上游忽略）。
"""
import json, os, random, time, urllib.request

BASE = "http://127.0.0.1:8020/api/v1/listings"
OUT = os.path.expanduser("~/listing_analysis")
os.makedirs(OUT, exist_ok=True)

def post(path, body, retries=3):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    for i in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read().decode())
        except Exception as e:
            if i == retries - 1:
                print("  FAIL", path, e)
                return None
            time.sleep(2)
    return None

def pace():
    time.sleep(random.uniform(0.8, 1.6))  # 模拟人工翻页节奏

def collect_sale(districts, pages=(1, 2), sort="period1_desc_createtime_desc"):
    items, seen = [], set()
    for name, dis in districts.items():
        for page in pages:
            resp = post("/sale/search", {"scope": "all", "district_id": dis,
                                         "page": page, "sort": sort})
            pace()
            if not resp:
                continue
            for it in resp.get("items", []):
                if it["listing_id"] not in seen:
                    seen.add(it["listing_id"]); items.append(it)
            print(f"  [买卖] {name} p{page}: 累计 {len(items)}")
    return items

def collect_rent(bands, pages=(1, 2, 3)):
    items, seen = [], set()
    for band in bands:
        for page in pages:
            resp = post("/rental/search", {"scope": "all", "page": page, "page_size": 50,
                                           "condition_filters": {"rentType": "001", "price": band}})
            pace()
            if not resp:
                continue
            for it in resp.get("items", []):
                if it["listing_id"] not in seen:
                    seen.add(it["listing_id"]); items.append(it)
            print(f"  [租赁] {band} p{page}: 累计 {len(items)}")
    return items

if __name__ == "__main__":
    SALE_DISTRICTS = {
        "锦江": "510104", "青羊": "510105", "金牛": "510106", "武侯": "510107",
        "成华": "510108", "龙泉驿": "510112", "双流": "510122", "温江": "510115",
        "新都": "510114", "郫都区": "510124", "天府新区": "23008850", "高新西": "23009121",
    }
    sale = collect_sale(SALE_DISTRICTS)
    json.dump(sale, open(os.path.join(OUT, "sale_listings.json"), "w", encoding="utf-8"), ensure_ascii=False)
    rent = collect_rent(["0:3000", "3000:4000", "4000:5000", "5000:6000",
                         "6000:8000", "8000:10000", "10000:-1"])
    json.dump(rent, open(os.path.join(OUT, "rental_listings.json"), "w", encoding="utf-8"), ensure_ascii=False)
    print(f"完成: 买卖 {len(sale)} / 租赁 {len(rent)}")
