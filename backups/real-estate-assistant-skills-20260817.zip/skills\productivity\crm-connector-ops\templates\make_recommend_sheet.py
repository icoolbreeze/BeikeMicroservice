# -*- coding: utf-8 -*-
"""房源推荐编号拼图 v2.1：卡片式编号拼图（推荐交付标准格式）。

用法:
    python make_recommend_sheet.py <data.json> <out.jpg> [--title "筛选条件"]
    data.json = [{no, price, layout, area, orient, community, tags, score,
                  level, title_url, floor_url}, ...]   (no 可省略，自动 1..n)

设计规范（用户 2026-08-14 定稿 v2.1）:
- 3 列卡片网格；每卡 = 实勘封面图 + 信息条
- 小区名醒目（信息条第 2 行，加粗大字）
- 左上角大号圆形编号徽章 → 用户报号即可取详情
- 按 score 降序排列（好房源排前面）
- 图片用最高分辨率公开版 .1500x.jpg（失败降级 .720x540.jpg，均无需 cookie）
- 输出 JPEG quality 95，>10MB 自动降质重存
"""
import json, os, sys, io, urllib.request

BASE = "https://img.ljcdn.com"
COLS = 3
CELL_W, IMG_H, LABEL_H = 760, 390, 112
HEADER_H = 76
FONT_B = "C:/Windows/Fonts/msyhbd.ttc"
FONT_R = "C:/Windows/Fonts/msyh.ttc"
LEVEL_COLOR = {"推荐": "#2ecc71", "可考虑": "#f1c40f", "谨慎": "#e74c3c"}
MAX_BYTES = 10 * 1024 * 1024  # 10MB


def public_url(url, size=".1500x.jpg"):
    if not url:
        return None
    url = url.split("!")[0]
    url = url.replace("https://img.ljcdn.com//", "https://img.ljcdn.com/")
    if url.startswith("/"):
        url = BASE + url
    if not url.endswith((".720x540.jpg", ".1500x.jpg")):
        url = url + size
    return url


def download(url):
    for size in (".1500x.jpg", ".720x540.jpg"):
        u = public_url(url, size)
        if not u:
            return None
        req = urllib.request.Request(u, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                data = r.read()
                if len(data) < 500:
                    print(f"  DL-EMPTY {size} {u[-50:]}")
                    continue
                return io.BytesIO(data)
        except Exception as e:
            print(f"  DL-FAIL {size} {u[-50:]} {e}")
    return None


def main():
    from PIL import Image, ImageDraw, ImageFont
    data_path, out_path = sys.argv[1], sys.argv[2]
    title = "房源推荐 · 回复编号查看详情"
    if "--title" in sys.argv:
        title = sys.argv[sys.argv.index("--title") + 1]
    items = json.load(open(data_path, encoding="utf-8"))
    for i, it in enumerate(items):
        it.setdefault("no", i + 1)
        it.setdefault("tags", "")
        it.setdefault("level", "")
    items.sort(key=lambda x: x.get("score", 0), reverse=True)  # 好房源排前面

    n = len(items)
    ROWS = (n + COLS - 1) // COLS
    W, H = COLS * CELL_W, HEADER_H + ROWS * (IMG_H + LABEL_H)
    sheet = Image.new("RGB", (W, H), "#141414")
    draw = ImageDraw.Draw(sheet)
    f_head = ImageFont.truetype(FONT_B, 32)
    f_num = ImageFont.truetype(FONT_B, 40)
    f_p1 = ImageFont.truetype(FONT_B, 30)   # 价格
    f_p2 = ImageFont.truetype(FONT_B, 26)   # 小区名
    f_p3 = ImageFont.truetype(FONT_R, 21)   # 户型面积朝向 / 等级
    f_p4 = ImageFont.truetype(FONT_R, 18)   # 标签
    f_score = ImageFont.truetype(FONT_B, 20)  # 评分环数字
    f_tiny = ImageFont.truetype(FONT_R, 13)   # 综合分说明

    draw.text((24, 18), title, font=f_head, fill="#ffd166")
    draw.text((W - 24, 26), f"共 {n} 套", font=f_p3, fill="#888", anchor="ra")

    ok = 0
    for idx, it in enumerate(items):
        col, row = idx % COLS, idx // COLS
        x, y = col * CELL_W, HEADER_H + row * (IMG_H + LABEL_H)
        img = download(it.get("title_url")) or download(it.get("floor_url"))
        if img is None:
            draw.rectangle([x, y, x + CELL_W, y + IMG_H], fill="#262626")
            draw.text((x + CELL_W // 2, y + IMG_H // 2 - 14), "无实勘图",
                      font=f_p3, fill="#777", anchor="mm")
        else:
            im = Image.open(img).convert("RGB")
            iw, ih = im.size
            scale = max(CELL_W / iw, IMG_H / ih)
            im = im.resize((int(iw * scale) + 1, int(ih * scale) + 1))
            im = im.crop(((im.width - CELL_W) // 2, (im.height - IMG_H) // 2,
                          (im.width - CELL_W) // 2 + CELL_W,
                          (im.height - IMG_H) // 2 + IMG_H))
            sheet.paste(im, (x, y))
            ok += 1
        # 编号徽章（左上角圆形）
        r = 36
        cx, cy = x + r + 10, y + r + 10
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill="#ff5a00",
                     outline="#ffffff", width=3)
        draw.text((cx, cy), str(it["no"]), font=f_num, fill="#ffffff",
                  anchor="mm")
        # 信息条：L1 价格(左) | 小区名(中) | 评分环(右)；L2 户型+等级；L3 标签
        by = y + IMG_H
        draw.rectangle([x, by, x + CELL_W, by + LABEL_H], fill="#0c0c0c")
        price = str(it.get("price", ""))
        draw.text((x + 16, by + 6), price, font=f_p1, fill="#ffd166")
        # 小区名：第一排中部居中
        comm = str(it.get("community", ""))
        draw.text((x + CELL_W // 2, by + 30), comm, font=f_p2,
                  fill="#ffffff", anchor="mm")
        # 评分环徽章（带"综合分"说明，颜色=等级）
        score = it.get("score")
        if score is not None:
            cx, cy, r = x + CELL_W - 58, by + 33, 27
            scol = "#2ecc71" if score >= 80 else "#f1c40f" if score >= 60 else "#e74c3c"
            draw.arc([cx - r, cy - r, cx + r, cy + r], 0, 360, fill="#3a3a3a", width=6)
            draw.arc([cx - r, cy - r, cx + r, cy + r], -90,
                     -90 + 360 * score / 100, fill=scol, width=6)
            draw.text((cx, cy - 1), str(score), font=f_score, fill="#ffffff",
                      anchor="mm")
            draw.text((cx, cy + r + 9), "综合分", font=f_tiny, fill="#9a9a9a",
                      anchor="mm")
        # L2：户型·面积·朝向 + 等级标签
        draw.text((x + 16, by + 62),
                  f"{it.get('layout','')} · {it.get('area','')}㎡ · {it.get('orient','')}",
                  font=f_p3, fill="#cfcfcf")
        level = it.get("level")
        if level and level in LEVEL_COLOR:
            lw = draw.textlength(level, font=f_p3) + 20
            draw.rounded_rectangle([x + CELL_W - 16 - lw, by + 60,
                                    x + CELL_W - 16, by + 92], radius=7,
                                   fill=LEVEL_COLOR[level])
            draw.text((x + CELL_W - 16 - lw / 2, by + 76), level, font=f_p3,
                      fill="#101010", anchor="mm")
        # L3：标签
        tags = str(it.get("tags", ""))
        if tags:
            draw.text((x + 16, by + 96), tags, font=f_p4,
                      fill="#ffb86c")

    # 保存：quality 95，>10MB 自动降质重存
    for q in (95, 90, 85, 80, 75):
        sheet.save(out_path, quality=q)
        size = os.path.getsize(out_path)
        if size <= MAX_BYTES:
            break
        print(f"  {size//1024//1024}MB >10MB, 降质到 {q-5}")
    print(f"OK {ok}/{n} -> {out_path} ({os.path.getsize(out_path)//1024}KB)")


if __name__ == "__main__":
    main()
