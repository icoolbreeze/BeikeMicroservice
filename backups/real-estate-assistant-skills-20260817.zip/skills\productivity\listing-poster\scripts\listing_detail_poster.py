"""房源详情竖向拼图生成器 v5：封面 hero + 客户向规格 + 实勘两列网格 + 户型图收尾。

v5（2026-08-15 整版替换定稿）客户向重设计，相对 v4 的变化：
- 封面照片升级为 hero 大图（底部渐变叠加小区/户型摘要 + 价格大字 +
  可选「海报编号 N」金标——替代内部 listing_id 作为客户侧标识）。
- 规格格 4 → 8：户型/面积/朝向/楼层 + 电梯/入住/水电气/看房
  （detail.elevator / live_time / utility / viewing，可由 house_info 的
  property_info、maintain 字段自动映射，缺失显示 —）。
- 元信息 chips 只留客户向：状态（有效→在租）、新上（挂牌≤3天）、
  省心租房管、特色标签；**维护门店/来源/房屋等级/带看次数不再渲染**
  （内部作业字段，客户向禁止，v4 的合规漏洞）。
- 评分不再显示分数（含 >100 的视觉修正叠加值），score_label 存在时
  作为 hero 金标 chip；show_listing_id 内部模式才显示「房源编号」与分数。
- 实勘照片改两列网格（房间名玻璃角标 + 拍摄日期角标），长图缩短约一半；
  户型图全宽收尾。
- 客户向 note 含内部字样整体替换为「数据来源：贝壳平台」（同 poster v5）。

保持不变：CLI 参数、payload 结构（detail/prospect/tuoguan/score/tags/note）、
托管通道自动映射（primary_flag 封面置顶、house_type_images 全收尾、
房管/钥匙 chip）、CDN 后缀与占位图兜底、light/dark 双主题、竖向长图形态。

用法：
    python scripts/listing_detail_poster.py <payload.json> [--theme dark]
    python scripts/listing_detail_poster.py - < <(cat payload.json)

输出（默认 outputs/listing_detail_<时间戳>/）：
    - detail.png   长图（--scale 默认 1x；2x 大屏展示用）
    - detail.html  渲染用的 HTML

payload 结构：
    {
      "theme": "dark",
      "poster_no": "03",                   // 可选：海报编号（客户侧标识）
      "show_listing_id": false,            // 可选：内部模式显示房源编号+分数
      "detail": { ...rental_listing_get_detail 原始返回... },
      "prospect": { "photos": [...], "floor_plan_url": "..." },
      "tuoguan": { ...tuoguan_listing_get_detail 原始返回... },
      "score": 92, "score_label": "推荐",  // 可选
      "tags": ["电梯房"],                   // 可选
      "note": "数据来源：贝壳平台"           // 可选页脚
    }
"""
from __future__ import annotations

import argparse
import html
import json
import sys
from datetime import datetime
from pathlib import Path

try:  # Windows 控制台 UTF-8
    sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
except Exception:  # noqa: BLE001
    pass

ROOT = Path(__file__).resolve().parent.parent

# 复用 listing_poster.py 的图片下载/占位/主题防护逻辑
sys.path.insert(0, str(Path(__file__).resolve().parent))
from listing_poster import (  # noqa: E402
    PLACEHOLDER_DATA_URL,
    _score_tier,
    fetch_image_data_url,
    sanitize_note,
)

_THEME_VARS = {
    "light": """
        :root {
          --bg: #eef2f7;
          --text: #0f172a;
          --muted: #64748b;
          --card-bg: #ffffff;
          --card-border: rgba(203, 213, 225, 0.9);
          --chip-bg: #f1f5f9;
          --chip-border: #e2e8f0;
          --panel-bg: #f8fafc;
          --panel-border: #eef2f7;
          --accent: #0f766e;
          --accent-bg: #f0fdfa;
          --accent-border: #99f6e4;
          --price-rent: #dc2626;
          --price-sale: #0f766e;
          --hero-sub: #475569;
          --gold: #b45309;
        }
    """,
    "dark": """
        :root {
          --bg: #0d1526;
          --text: #edf2fa;
          --muted: #93a4c0;
          --card-bg: #162238;
          --card-border: #27395a;
          --chip-bg: #1d2c47;
          --chip-border: #31456b;
          --panel-bg: #121d31;
          --panel-border: #243b58;
          --accent: #2dd4bf;
          --accent-bg: rgba(45, 212, 191, 0.14);
          --accent-border: rgba(45, 212, 191, 0.45);
          --price-rent: #ff8a7a;
          --price-sale: #5eead4;
          --hero-sub: #d3deee;
          --gold: #fbbf24;
        }
    """,
}

_CSS = """
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
                   "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
      background: var(--bg); color: var(--text);
      padding: 34px 0 26px; display: flex; justify-content: center;
      -webkit-font-smoothing: antialiased;
    }
    .container { width: 100%; max-width: 1000px; margin: 0 auto; padding: 0 24px; }

    /* 封面 hero：大图 + 底部渐变信息层 */
    .hero { position: relative; border-radius: 20px; overflow: hidden;
            border: 1px solid var(--card-border); margin-bottom: 20px;
            background: var(--panel-bg); }
    .hero img { width: 100%; display: block; aspect-ratio: 4 / 3; object-fit: cover; }
    .hero-shade { position: absolute; inset: 0;
                  background: linear-gradient(180deg, rgba(8,13,26,0) 30%, rgba(8,13,26,.88) 100%); }
    .hero-text { position: absolute; left: 22px; right: 22px; bottom: 16px;
                 display: flex; justify-content: space-between;
                 align-items: flex-end; gap: 12px; }
    .hero-left { min-width: 0; }
    .hero-chips { display: flex; gap: 6px; margin-bottom: 8px; flex-wrap: wrap; }
    .hero-no { font-size: 12px; font-weight: 800; color: #1f2937;
               background: linear-gradient(135deg, #fde68a, #fbbf24);
               padding: 3px 10px; border-radius: 999px; white-space: nowrap; }
    .hero-badge { font-size: 12px; font-weight: 800; color: #1f2937;
                  background: linear-gradient(135deg, #5eead4, #2dd4bf);
                  padding: 3px 10px; border-radius: 999px; white-space: nowrap; }
    .hero-room { position: absolute; top: 12px; left: 12px;
                 background: rgba(10, 16, 30, 0.66); backdrop-filter: blur(8px);
                 color: #fff; font-size: 12px; font-weight: 700;
                 padding: 3px 10px; border-radius: 8px;
                 border: 1px solid rgba(255, 255, 255, 0.22); }
    .hero-community { font-size: 24px; font-weight: 800; color: #ffffff;
                      text-shadow: 0 2px 10px rgba(0,0,0,.6); white-space: nowrap;
                      overflow: hidden; text-overflow: ellipsis; }
    .hero-sub { font-size: 13px; color: var(--hero-sub); margin-top: 3px; }
    .hero-price { text-align: right; white-space: nowrap; }
    .hero-price .amount { font-size: 34px; font-weight: 800;
                          color: var(--price-rent); letter-spacing: -0.5px; }
    .hero-price .amount.sale { color: var(--price-sale); }
    .hero-price .unit { font-size: 14px; color: var(--hero-sub); font-weight: 600; }

    .card { background: var(--card-bg); border-radius: 20px;
            border: 1px solid var(--card-border); padding: 20px 24px;
            margin-bottom: 20px; }

    /* 8 格规格：4 基础 + 4 生活（电梯/入住/水电气/看房） */
    .spec-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
    .spec-item { background: var(--panel-bg); border: 1px solid var(--panel-border);
                 border-radius: 12px; padding: 10px 8px; text-align: center; }
    .spec-label { font-size: 11px; color: var(--muted); font-weight: 600; }
    .spec-value { font-size: 15px; font-weight: 800; margin-top: 3px;
                  font-variant-numeric: tabular-nums; white-space: nowrap;
                  overflow: hidden; text-overflow: ellipsis; }

    .meta-row { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 14px; }
    .meta-chip { font-size: 12px; font-weight: 600;
                 color: var(--text); background: var(--chip-bg);
                 border: 1px solid var(--chip-border);
                 padding: 4px 12px; border-radius: 999px; white-space: nowrap; }
    .meta-chip.accent { color: var(--accent); background: var(--accent-bg);
                        border-color: var(--accent-border); }

    .section-title { font-size: 16px; font-weight: 800; margin-bottom: 12px;
                     display: flex; align-items: center; gap: 8px; }
    .section-title .count { font-size: 12px; color: var(--muted); font-weight: 600;
                            background: var(--chip-bg);
                            border: 1px solid var(--chip-border);
                            padding: 3px 10px; border-radius: 999px; }

    /* 实勘两列网格：房间名 + 拍摄日期玻璃角标 */
    .photo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .photo-cell { position: relative; border-radius: 14px; overflow: hidden;
                  border: 1px solid var(--card-border); background: var(--panel-bg); }
    .photo-cell img { width: 100%; aspect-ratio: 4 / 3; object-fit: cover;
                      display: block; }
    .room-badge { position: absolute; top: 8px; left: 8px;
                  background: rgba(10, 16, 30, 0.66); backdrop-filter: blur(8px);
                  color: #fff; font-size: 11.5px; font-weight: 700;
                  padding: 3px 10px; border-radius: 8px;
                  border: 1px solid rgba(255, 255, 255, 0.22); }
    .photo-time { position: absolute; right: 8px; bottom: 8px;
                  font-size: 10.5px; color: #e6edf7; font-weight: 600;
                  background: rgba(10, 16, 30, 0.6); padding: 2px 8px;
                  border-radius: 6px; backdrop-filter: blur(6px); }

    /* 户型图全宽收尾 */
    .photo-wide { position: relative; border-radius: 14px; overflow: hidden;
                  border: 1px solid var(--card-border); margin-bottom: 10px;
                  background: var(--panel-bg); }
    .photo-wide img { width: 100%; display: block; }

    .footer { margin-top: 6px; text-align: center; font-size: 12px;
              color: var(--muted); line-height: 1.8; }
    .footer .cta { color: var(--gold); font-weight: 700; }
"""


def _normalize_tuoguan_payload(payload: dict) -> dict:
    """把 payload.tuoguan（tuoguan_listing_get_detail 原始返回）映射进
    detail/prospect 结构；显式传入的 detail/prospect 字段优先。"""
    tg = payload.get("tuoguan")
    if not isinstance(tg, dict):
        return payload
    detail = dict(payload.get("detail") or {})
    prospect = dict(payload.get("prospect") or {})
    photos = list(prospect.get("photos") or [])

    def setdefault(key, value):
        if value is not None and not detail.get(key):
            detail[key] = value

    setdefault("listing_id", tg.get("house_del_code") or tg.get("cell_code"))
    setdefault("community", tg.get("resblock_name"))
    setdefault("layout", tg.get("house_type_desc"))
    setdefault("area_sqm", tg.get("area_number"))
    setdefault("monthly_rent_yuan", tg.get("guide_price_yuan"))
    setdefault("orientation", tg.get("orientation"))
    setdefault("floor_desc", tg.get("floor_type"))
    setdefault("total_floors", tg.get("total_floor"))
    # 客户向生活字段：托管侧 can_live_time / key_desc 直接可用
    setdefault("live_time", tg.get("can_live_time"))
    if tg.get("key_desc"):
        detail.setdefault("viewing", f"{tg['key_desc']} · 随时可看")
    elif tg.get("has_smart_key"):
        detail.setdefault("viewing", "智能门锁 · 随时可看")
    manager = tg.get("manager")
    if isinstance(manager, dict):
        parts = [
            str(manager.get("user_name") or "").strip(),
            str(manager.get("org_name") or "").strip(),
        ]
        manager_text = "/".join(p for p in parts if p)
        if manager_text:
            detail.setdefault("manager_text", manager_text)

    for photo in tg.get("prospects") or []:
        if not isinstance(photo, dict) or not photo.get("url"):
            continue
        photos.append(
            {
                "url": photo.get("url"),
                "room_name": photo.get("name"),
                "image_type": "TITLE" if photo.get("primary_flag") else "REAL",
                "upload_user": None,
                "created_at": photo.get("create_time"),
            }
        )
    prospect["photos"] = photos

    floor_plans = [u for u in (tg.get("house_type_images") or []) if u]
    if floor_plans:
        prospect["floor_plans"] = floor_plans
    payload["detail"] = detail
    payload["prospect"] = prospect
    return payload


def _fmt_area(value) -> str | None:
    try:
        return f"{float(value):g}㎡"
    except (TypeError, ValueError):
        return None


def _fmt_price(detail: dict) -> tuple[str, str, str]:
    """返回 (price_primary, price_unit, css_class)；租赁/买卖都兼容。"""
    rent = detail.get("monthly_rent_yuan")
    if rent is not None:
        return f"¥{float(rent):,.0f}", "/月", ""
    total = detail.get("total_price_yuan")
    if total is not None:
        return f"{float(total) / 10000:g}万", "", " sale"
    text = detail.get("total_price_text")
    if text:
        return str(text), "", ""
    return "—", "", ""


def _derive_living_specs(detail: dict) -> dict:
    """生活规格字段（电梯/入住/水电气/看房）的自动映射与默认值。

    显式 detail.elevator / live_time / utility / viewing 优先；否则从
    house_info 的 property_info、maintain 惯例字段名兜底；水电气由
    民水+民电合成。缺失一律显示 —（不猜）。
    """
    elevator = detail.get("elevator") or detail.get("elevator_text")
    live_time = detail.get("live_time") or detail.get("can_live_time")
    utility = detail.get("utility")
    if not utility:
        water = str(detail.get("water_type") or "")
        electric = str(detail.get("electric_type") or "")
        if "民水" in water and "民电" in electric:
            utility = "民水民电"
        elif water:
            utility = water
    viewing = detail.get("viewing")
    if not viewing:
        if detail.get("key_text"):
            viewing = f"{detail['key_text']} · 随时可看"
        elif detail.get("has_key"):
            viewing = "有钥匙 · 随时可看"
    return {
        "elevator": str(elevator) if elevator else "—",
        "live_time": str(live_time) if live_time else "—",
        "utility": str(utility) if utility else "—",
        "viewing": str(viewing) if viewing else "—",
    }


def _status_text(detail: dict) -> str | None:
    """状态 chip 文案：内部枚举翻译成客户语言。"""
    text = detail.get("del_status_text")
    if not text:
        return None
    return {"有效": "在租"}.get(str(text), str(text))


def _shot_date(p: dict) -> str:
    t = str(p.get("created_at") or "")
    return t[:10].replace("-", "/") if t else ""


def build_html(payload: dict, theme: str) -> str:
    esc = html.escape
    detail = payload.get("detail") or {}
    prospect = payload.get("prospect") or {}
    photos = list(prospect.get("photos") or [])
    floor_plan_url = prospect.get("floor_plan_url")
    floor_plans = list(prospect.get("floor_plans") or [])
    internal = bool(payload.get("show_listing_id"))

    # 封面（TITLE 优先）做 hero；其余进两列网格，顺序保持上游分组
    cover = next(
        (p for p in photos if str(p.get("image_type") or "").upper() == "TITLE"),
        photos[0] if photos else None,
    )
    rest = [p for p in photos if p is not cover]

    community = detail.get("community") or "—"
    area = _fmt_area(detail.get("area_sqm")) or "—"
    floor_text = str(detail.get("floor_desc") or "—")
    if detail.get("total_floors"):
        floor_text += f"/{detail.get('total_floors')}F"

    price_primary, price_unit, price_cls = _fmt_price(detail)

    # hero chips：海报编号（客户标识）/ 档位（score_label，不带分数）
    hero_chips = []
    if payload.get("poster_no"):
        hero_chips.append(
            f'<span class="hero-no">海报编号 {esc(str(payload["poster_no"]))}</span>'
        )
    elif internal and detail.get("listing_id"):
        hero_chips.append(
            f'<span class="hero-no">房源编号 {esc(str(detail["listing_id"]))}</span>'
        )
    tier = payload.get("score_label")
    if not tier:
        t = _score_tier(payload.get("score"))
        tier = t[1] if t else None
    if tier:
        if internal and payload.get("score") is not None:
            try:
                tier = f"★{int(float(payload['score']))} {tier}"
            except (TypeError, ValueError):
                pass
        hero_chips.append(f'<span class="hero-badge">{esc(str(tier))}</span>')

    hero = ""
    if cover:
        hero_img = cover.get("image_data_url") or PLACEHOLDER_DATA_URL
        hero_room = str(cover.get("room_name") or "封面")
        hero = (
            '<div class="hero">'
            f'<img src="{hero_img}" alt="封面">'
            f'<span class="hero-room">{esc(hero_room)}</span>'
            '<div class="hero-shade"></div>'
            '<div class="hero-text">'
            f'<div class="hero-left"><div class="hero-chips">{"".join(hero_chips)}</div>'
            f'<div class="hero-community">{esc(str(community))}</div>'
            f'<div class="hero-sub">{esc(str(detail.get("layout") or "—"))} · {esc(area)} · '
            f'{esc(str(detail.get("orientation") or "—"))} · {esc(floor_text)}</div></div>'
            f'<div class="hero-price"><span class="amount{price_cls}">{esc(price_primary)}</span>'
            f'<span class="unit">{esc(price_unit)}</span></div>'
            "</div></div>"
        )

    # 8 格规格：4 基础 + 4 生活（客户真正关心的）
    living = _derive_living_specs(detail)
    specs = [
        ("户型", detail.get("layout") or "—"),
        ("面积", area),
        ("朝向", detail.get("orientation") or "—"),
        ("楼层", floor_text),
        ("电梯", living["elevator"]),
        ("入住", living["live_time"]),
        ("水电气", living["utility"]),
        ("看房", living["viewing"]),
    ]
    spec_html = "".join(
        f'<div class="spec-item"><div class="spec-label">{esc(str(k))}</div>'
        f'<div class="spec-value">{esc(str(v))}</div></div>'
        for k, v in specs
    )

    # 客户向 chips：状态 / 新上 / 省心租房管 / 特色标签
    # （维护门店、来源、房屋等级、带看次数是内部字段，一律不渲染）
    chips = []
    status = _status_text(detail)
    if status:
        chips.append(f'<span class="meta-chip">● {esc(status)}</span>')
    listed_days = detail.get("listed_days")
    if isinstance(listed_days, (int, float)) and listed_days <= 3:
        chips.append(
            '<span class="meta-chip accent">今日新上</span>'
            if listed_days <= 1 else
            '<span class="meta-chip accent">3日内新上</span>'
        )
    if detail.get("manager_text"):
        chips.append(
            f'<span class="meta-chip">省心租房管 {esc(str(detail["manager_text"]))}</span>'
        )
    for tag in (payload.get("tags") or [])[:4]:
        chips.append(f'<span class="meta-chip accent">{esc(str(tag))}</span>')
    meta_html = f'<div class="meta-row">{"".join(chips)}</div>' if chips else ""

    cells = "".join(
        '<div class="photo-cell">'
        f'<img src="{p.get("image_data_url") or PLACEHOLDER_DATA_URL}" '
        f'alt="{esc(str(p.get("room_name") or ""))}">'
        f'<span class="room-badge">{esc(str(p.get("room_name") or "照片"))}</span>'
        + (f'<span class="photo-time">{esc(_shot_date(p))}</span>' if _shot_date(p) else "")
        + "</div>"
        for p in rest
    )

    all_floor_plans = []
    if floor_plan_url:
        all_floor_plans.append(floor_plan_url)
    all_floor_plans.extend(floor_plans)
    plan_html = "".join(
        f'<div class="photo-wide"><img src="{u}" alt="户型图"></div>'
        for u in all_floor_plans
    )

    note = sanitize_note(payload.get("note"), internal=internal)
    generated = datetime.now().strftime("%Y-%m-%d %H:%M")
    footer_note = " · ".join(part for part in (note, f"生成于 {generated}") if part)

    css = _THEME_VARS.get(theme, _THEME_VARS["dark"]) + _CSS
    return (
        "<!DOCTYPE html>\n"
        '<html lang="zh-CN">\n<head>\n<meta charset="UTF-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
        f"<title>{esc(str(community))} 房源详情</title>\n<style>{css}</style>\n</head>\n<body>\n"
        '<div class="container">'
        f"{hero}"
        f'<section class="card"><div class="spec-grid">{spec_html}</div>{meta_html}</section>'
        + (
            f'<section class="card"><div class="section-title">实勘照片'
            f'<span class="count">{len(rest)} 张 · {_shot_date(cover) or "实拍"}</span></div>'
            f'<div class="photo-grid">{cells}</div></section>'
            if cells else ""
        )
        + (
            f'<section class="card"><div class="section-title">户型图</div>{plan_html}</section>'
            if plan_html else ""
        )
        + (
            f'<div class="footer">{esc(footer_note)}<br>'
            '<span class="cta">满意可约实地看房 · 详情以实地为准</span></div>'
        )
        + "</div>\n</body>\n</html>"
    )


def main() -> int:
    ap = argparse.ArgumentParser(description="房源详情竖向拼图 v5（hero+规格+两列实勘+户型图）")
    ap.add_argument("payload", help="payload JSON 文件路径，或用 '-' 从 stdin 读取")
    ap.add_argument("--out", type=Path, default=None, help="输出目录（默认 outputs/listing_detail_<时间戳>）")
    ap.add_argument("--theme", choices=["light", "dark"], default="dark", help="主题（默认 dark）")
    ap.add_argument("--image-size", type=int, default=1500, choices=(450, 750, 800, 1500),
                    help="CDN 尺寸后缀（默认 1500 高清；两列网格场景 750 也可用）")
    ap.add_argument("--timeout", type=float, default=15, help="单张图片下载超时秒数（默认 15）")
    ap.add_argument("--no-download", action="store_true", help="不下载图片，全部用占位图")
    ap.add_argument("--scale", type=int, default=1, help="导出缩放倍率（默认 1；2x 体积约 3 倍，仅大屏展示需要）")
    ap.add_argument("--width", type=int, default=1000, help="渲染视口宽度（默认 1000）")
    args = ap.parse_args()

    if args.payload == "-":
        payload = json.loads(sys.stdin.read())
    else:
        path = Path(args.payload)
        if not path.exists():
            sys.exit(f"输入文件不存在：{path}")
        payload = json.loads(path.read_text(encoding="utf-8"))

    payload = _normalize_tuoguan_payload(payload)
    detail = payload.get("detail") or {}
    if not detail:
        sys.exit("payload.detail 缺失")
    prospect = payload.get("prospect") or {}
    photos = list(prospect.get("photos") or [])
    floor_plan_url = prospect.get("floor_plan_url")
    floor_plans = list(prospect.get("floor_plans") or [])
    if not photos and not floor_plan_url and not floor_plans:
        sys.exit("prospect 无照片也无户型图，无可渲染内容")

    theme = payload.get("theme") or args.theme
    out_dir = args.out or (ROOT / "outputs" / f"listing_detail_{datetime.now():%Y%m%d_%H%M%S}")
    out_dir.mkdir(parents=True, exist_ok=True)

    total_images = len(photos) + (1 if floor_plan_url else 0) + len(floor_plans)
    print(f"[1/2] 下载 {total_images} 张图片（.x{args.image_size} 公开后缀）")
    urls = []
    for p in photos:
        if p.get("url"):
            urls.append(p["url"])
    if floor_plan_url:
        urls.append(floor_plan_url)
    urls.extend(floor_plans)
    unique = sorted(set(urls))
    if args.no_download:
        for p in photos:
            p["image_data_url"] = PLACEHOLDER_DATA_URL
        if floor_plan_url:
            payload.setdefault("prospect", {})["floor_plan_url"] = PLACEHOLDER_DATA_URL
        if floor_plans:
            payload.setdefault("prospect", {})["floor_plans"] = [
                PLACEHOLDER_DATA_URL for _ in floor_plans
            ]
    else:
        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor(max_workers=6) as pool:
            results = pool.map(
                lambda u: fetch_image_data_url(u, args.image_size, args.timeout),
                unique,
            )
        cache = dict(zip(unique, results))
        for p in photos:
            if p.get("url") in cache:
                p["image_data_url"] = cache[p["url"]]
        floor_plan_data = cache.get(floor_plan_url) if floor_plan_url else None
        if floor_plan_data:
            payload.setdefault("prospect", {})["floor_plan_url"] = floor_plan_data
        if floor_plans:
            payload.setdefault("prospect", {})["floor_plans"] = [
                cache.get(u) or PLACEHOLDER_DATA_URL for u in floor_plans
            ]

    html_text = build_html(payload, theme)
    html_path = out_dir / "detail.html"
    html_path.write_text(html_text, encoding="utf-8")

    print(f"[2/2] Playwright 无头渲染（{theme} 主题，竖向长图，{args.scale}x）")
    from listing_poster import render_png

    png_path = out_dir / "detail.png"
    render_png(html_text, png_path, args.width, args.scale)
    print(f"详情图已生成：{png_path}")
    print(f"HTML 预览：{html_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
