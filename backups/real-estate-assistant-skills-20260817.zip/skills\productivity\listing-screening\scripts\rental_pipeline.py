#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""租赁房源查询通用流水线（HTTP 8020 本地通道，全流程无 MCP 限流）。

用法示例:
  # 全流程一键（天府广场附近1km 套一 1000-2500 整租）
  python rental_pipeline.py --location "天府广场" --radius 1000 \
      --price 1000:2500 --rooms 1 --rent-type 001 --target-price 2000

  # 分阶段（断点续跑，已生成的文件跳过）
  python rental_pipeline.py --location "天府广场" --stage collect
  python rental_pipeline.py --location "天府广场" --stage score
  python rental_pipeline.py --location "天府广场" --stage covers
  python rental_pipeline.py --location "天府广场" --stage prospect --top 50
  python rental_pipeline.py --location "天府广场" --stage fullhouse
  python rental_pipeline.py --location "天府广场" --stage tags --final 15
  python rental_pipeline.py --location "天府广场" --stage poster --vision vision_scores.json

阶段:
  collect   位置解析(map nearby) -> community_ids -> 翻页采集全字段 -> listings.json
  score     数据分粗筛(A-D 100分制, 价格信号按 target-price 平移) -> scored.json / pool1.json
  covers    封面 sheet 拼图(16套/张) -> covers/sheet_*.png + sheet_map.json (供 vision 批量速评)
  prospect  候选池 top N 普租 5 并发拉全屋实勘 -> prospects/*.json
  fullhouse 每套全屋图拼接(每房间类型至少1张, 上限7张回填; 普租读本地实勘 / 托管按 getRedirectUrl 回链详情) -> fullhouse/full_*.png (供逐套 vision 评分)
  tags      最终名单 top F 拉详情+house-info -> details/*.json, 提取特色标签写回 finalN.json
  poster    汇总(数据分+视觉分) -> 构造 payload -> 调 listing-poster 渲染海报

视觉分: agent 对 covers/fullhouse 图做 vision_analyze 后, 写 {listing_id: int} 到
        vision_scores.json (out 目录), poster 阶段读取并入总分。
输出: --out 目录(默认 ~/listing_analysis/<location-slug>/)
"""
import argparse, json, os, random, re, statistics, sys, time, urllib.error, urllib.request
from concurrent.futures import ThreadPoolExecutor

BASE = "http://127.0.0.1:8020"
HDRS = {"Content-Type": "application/json"}
UA = {"User-Agent": "Mozilla/5.0", "Referer": "https://cd.ke.com/"}


# ---------- HTTP ----------
def post(path, body, retries=3):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode(), headers=HDRS)
    for i in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=25) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            # Invalid candidate ids are expected while resolving house_del_code
            # to cell_code.  Retrying a deterministic 400 only delays the
            # next candidate; keep retries for auth refresh/rate limiting.
            if 400 <= e.code < 500 and e.code not in (401, 403, 429):
                print("  FAIL", path, e, flush=True)
                return None
            if i == retries - 1:
                print("  FAIL", path, e, flush=True)
                return None
            time.sleep(2)
        except Exception as e:
            if i == retries - 1:
                print("  FAIL", path, e)
                return None
            time.sleep(2)
    return None


def get(path, retries=3):
    req = urllib.request.Request(BASE + path)
    for i in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=25) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if 400 <= e.code < 500 and e.code not in (401, 403, 429):
                print("  FAIL", path, e, flush=True)
                return None
            if i == retries - 1:
                print("  FAIL", path, e, flush=True)
                return None
            time.sleep(2)
        except Exception as e:
            if i == retries - 1:
                print("  FAIL", path, e)
                return None
            time.sleep(2)
    return None


def pace():
    time.sleep(random.uniform(0.8, 1.6))


# ---------- 图片 ----------
def public_url(url):
    """公开变体 = 原 URL 追加 .750x.jpg（append，非替换扩展名，全 bucket 通用）。"""
    if not url:
        return None
    url = url.split("!")[0]
    if url.endswith((".750x.jpg", ".450x.jpg", ".1500x.jpg")):
        return url
    return url + ".750x.jpg"


def dl(url, path):
    if not url or os.path.exists(path):
        return path if os.path.exists(path) else None
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=15) as r, open(path, "wb") as f:
            f.write(r.read())
        return path
    except Exception:
        return None


def get_tuoguan_detail(cell_code):
    """Fetch one trusteeship detail by the workbench ``cell_code``."""
    return get(f"/api/v1/listings/rental/tuoguan/{cell_code}")


def _norm_match_text(value):
    """Normalize display text for cross-domain inventory matching."""
    return re.sub(r"[\s·•()（）_\-/]", "", str(value or "")).lower()


def _layout_part(value, label):
    match = re.search(rf"(\d+)\s*{label}", str(value or ""))
    return int(match.group(1)) if match else None


def _tuoguan_candidate_score(listing, row):
    """Score a waiting-rent row as a possible match for a rental row.

    The waiting-rent endpoint does not expose ``house_del_code``.  Matching
    is therefore only a candidate step; every candidate is verified later by
    the detail response's house_del_code before it can be used.
    """
    if _norm_match_text(listing.get("community")) != _norm_match_text(row.get("community")):
        return None

    score = 100
    listing_price = listing.get("monthly_rent_yuan")
    guide_price = row.get("guide_price_yuan")
    if listing_price is not None and guide_price is not None:
        price_diff = abs(float(listing_price) - float(guide_price))
        if price_diff > 1200:
            return None
        score += 30 if price_diff == 0 else 20 if price_diff <= 100 else 10 if price_diff <= 300 else 0

    listing_area = listing.get("area_sqm")
    row_area = row.get("area_sqm")
    if listing_area is not None and row_area is not None:
        area_diff = abs(float(listing_area) - float(row_area))
        if area_diff > 12:
            return None
        score += 20 if area_diff <= 0.5 else 12 if area_diff <= 2 else 5 if area_diff <= 5 else 0

    listing_rooms = _layout_part(listing.get("layout"), "室")
    row_rooms = _layout_part(row.get("layout_text"), "室")
    if listing_rooms is not None and row_rooms is not None:
        if listing_rooms != row_rooms:
            return None
        score += 10
    listing_baths = _layout_part(listing.get("layout"), "卫")
    row_baths = _layout_part(row.get("layout_text"), "卫")
    if listing_baths is not None and row_baths is not None:
        if listing_baths != row_baths:
            return None
        score += 10
    return score


def load_tuoguan_inventory(out, refresh=False):
    """Load the trusteeship waiting-rent inventory used as a cell_code fallback.

    The primary path is the page's own getRedirectUrl (house→cell, added to
    the connector as ``/listings/rental/{listing_id}/redirect``).  When that
    has no trusteeship redirect, the waiting-rent inventory is scanned for
    candidate cell_code rows, each verified by the detail house_del_code.
    """
    path = os.path.join(out, "tuoguan_inventory.json")
    if not refresh and os.path.exists(path):
        try:
            cached = json.load(open(path, encoding="utf-8"))
            rows = cached.get("items") if isinstance(cached, dict) else cached
            if isinstance(rows, list):
                return rows
        except Exception:
            pass

    rows = []
    page = 1
    max_pages = 100  # 300/页 × 100 = 30000 行，远超当前库存量级，防上游 has_more 异常
    while page <= max_pages:
        resp = post("/api/v1/listings/rental/tuoguan/search", {
            "page": page, "page_size": 300,
        })
        if resp is None:
            print(f"[tuoguan] 待出租库存第 {page} 页获取失败", flush=True)
            return None
        batch = resp.get("items") or []
        rows.extend(batch)
        print(f"[tuoguan] 库存第 {page} 页 +{len(batch)} 累计 {len(rows)}", flush=True)
        if not resp.get("has_more"):
            break
        page += 1
        pace()
    if page > max_pages:
        print("[tuoguan] 库存页数超过上限 100 页，截断（上游 has_more 异常）", flush=True)

    json.dump(
        {"fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S"), "items": rows},
        open(path, "w", encoding="utf-8"), ensure_ascii=False,
    )
    return rows


def _read_verified_tuoguan_detail(listing_id, details_dir):
    path = os.path.join(details_dir, f"tuoguan_{listing_id}.json")
    if not os.path.exists(path):
        return None
    try:
        detail = json.load(open(path, encoding="utf-8"))
    except Exception:
        return None
    if str(detail.get("house_del_code") or "") != str(listing_id):
        return None
    return detail


def get_redirect_cell_code(listing_id):
    """Resolve a managed row's trusteeship cell_code via getRedirectUrl.

    Mirrors the 房源列表 page: clicking a managed row calls
    getRedirectUrl?delCode=<id>&delType=5 and opens the returned trusteeship
    URL, whose last segment is the cell_code. This is the exact click path —
    no inventory scanning needed.
    """
    resp = get(f"/api/v1/listings/rental/{listing_id}/redirect")
    if not isinstance(resp, dict):
        return None
    return str(resp.get("cell_code") or "") or None


def resolve_tuoguan_detail(listing, inventory, details_dir):
    """Resolve and verify one rental row's trusteeship detail.

    Primary path is the page's own getRedirectUrl (house→cell).  Inventory
    candidate matching is only a fallback, and in both cases the detail
    response must echo the target ``house_del_code`` so two units in the same
    community with similar rent/area can never be crossed.
    """
    listing_id = str(listing["listing_id"])
    cached = _read_verified_tuoguan_detail(listing_id, details_dir)
    if cached is not None:
        return cached, "缓存·详情回链校验"

    redirect_cell = get_redirect_cell_code(listing_id)
    if redirect_cell:
        detail = get_tuoguan_detail(redirect_cell)
        if str((detail or {}).get("house_del_code") or "") == listing_id:
            path = os.path.join(details_dir, f"tuoguan_{listing_id}.json")
            json.dump(detail, open(path, "w", encoding="utf-8"), ensure_ascii=False)
            return detail, f"cell_code={redirect_cell}·getRedirectUrl 回链校验"
        redirect_reason = f"getRedirectUrl 返回 {redirect_cell} 但详情未回链到目标房源"
    else:
        redirect_reason = "getRedirectUrl 无托管跳转"

    if not inventory:
        return None, redirect_reason

    candidates = []
    for row in inventory:
        score = _tuoguan_candidate_score(listing, row)
        if score is not None and row.get("cell_code"):
            candidates.append((score, row))
    candidates.sort(key=lambda item: -item[0])
    if not candidates:
        return None, redirect_reason + "，且未找到可匹配的 cell_code"

    for score, row in candidates:
        cell_code = str(row["cell_code"])
        detail = get_tuoguan_detail(cell_code)
        if str((detail or {}).get("house_del_code") or "") != listing_id:
            continue
        path = os.path.join(details_dir, f"tuoguan_{listing_id}.json")
        json.dump(detail, open(path, "w", encoding="utf-8"), ensure_ascii=False)
        return detail, f"cell_code={cell_code} 候选分{score}·详情回链校验"
    return None, f"{redirect_reason}，且 {len(candidates)} 个候选 cell_code 均未回链到目标房源"


def resolve_tuoguan_rows(rows, out, inventory):
    """Resolve a batch of trusteeship rows with bounded concurrency."""
    details_dir = os.path.join(out, "details")
    os.makedirs(details_dir, exist_ok=True)

    def fetch(row):
        detail, message = resolve_tuoguan_detail(row, inventory, details_dir)
        row["_tuoguan"] = detail
        row["_tuoguan_source"] = message
        return row, message

    with ThreadPoolExecutor(max_workers=5) as ex:
        return list(ex.map(fetch, rows))


# ---------- 阶段: collect ----------
def stage_collect(args, out):
    print("[collect] 解析位置:", args.location)
    nearby_body = {
        "location": args.location,
        "radius_meters": args.radius,
        "price_min_yuan": args.price_min,
        "price_max_yuan": args.price_max,
    }
    if args.rooms is not None:
        nearby_body["rooms"] = args.rooms
    if args.rental_modes is not None:
        nearby_body["rental_modes"] = args.rental_modes
    nb = post("/api/v1/listings/rental/map/nearby", nearby_body)
    pace()
    if not nb:
        sys.exit("位置解析失败")
    comm_ids = (nb.get("community_ids") or [])[:100]
    center = nb.get("center") or {}
    print(f"  中心: {center.get('name')}({center.get('item_type')}) 小区数: {len(comm_ids)}")
    if not comm_ids:
        sys.exit("圈内无小区")

    items, seen = [], set()
    # bedroomAmount 单选：多室数(如 1,2)分次查询后合并去重；未指定室数时
    # 仍需执行一次不限户型的查询，不能让空列表跳过整个采集阶段。
    if args.bedroom_amount is not None:
        room_vals = [args.bedroom_amount]
    elif args.rooms:
        room_vals = [str(r) for r in args.rooms]
    else:
        room_vals = [None]
    for rv in room_vals:
        room_label = rv if rv is not None else "不限"
        for page in range(1, 30):
            resp = post("/api/v1/listings/rental/search", {
                "scope": "all", "page": page, "page_size": 50,
                "resblock_ids": comm_ids,
                "condition_filters": {k: v for k, v in {
                    "price": args.price, "rentType": args.rent_type,
                    "bedroomAmount": rv,
                }.items() if v},
            })
            pace()
            if not resp:
                break
            batch = resp.get("items", [])
            if not batch:
                break
            for it in batch:
                if it["listing_id"] not in seen:
                    seen.add(it["listing_id"])
                    items.append(it)
            print(f"  室数{room_label} p{page}: +{len(batch)} 累计 {len(items)}", flush=True)
            if not resp.get("has_more"):
                break
    json.dump(items, open(os.path.join(out, "listings.json"), "w", encoding="utf-8"), ensure_ascii=False)
    json.dump({"center": center, "community_ids": comm_ids, "count": len(items)},
              open(os.path.join(out, "meta.json"), "w", encoding="utf-8"), ensure_ascii=False)
    print(f"[collect] 完成: {len(items)} 套")


# ---------- 阶段: score ----------
def stage_score(args, out):
    items = json.load(open(os.path.join(out, "listings.json"), encoding="utf-8"))
    if not items:
        sys.exit("无数据，先跑 collect")
    print(f"[score] 打分 {len(items)} 套")
    unit_prices = sorted(it["monthly_rent_yuan"] / it["area_sqm"] for it in items if it.get("area_sqm"))
    n = len(unit_prices)
    pct = lambda p: unit_prices[min(n - 1, int(p * n))]
    p30, p50, p70, p90 = pct(0.30), pct(0.50), pct(0.70), pct(0.90)
    print(f"  每㎡租金分位: p30={p30:.1f} p50={p50:.1f} p70={p70:.1f} p90={p90:.1f}")

    # 同小区同户型均值（SKILL 规则：同小区同户型总价明显高于均值才扣分）
    comm_mean = {}
    for it in items:
        m = re.match(r"(\d+)", str(it.get("layout") or ""))
        comm_mean.setdefault((it["community"], m.group(1) if m else "?"), []).append(it["monthly_rent_yuan"])
    comm_mean = {k: statistics.mean(v) for k, v in comm_mean.items()}

    # 价格信号主流段：target-price ±300 →10；±800 →7；其余 →4
    def price_signal(p):
        t = args.target_price or ((args.price_min or 0) + (args.price_max or 0)) // 2
        if t - 300 <= p <= t + 300: return 10
        if t - 800 <= p < t - 300 or t + 300 < p <= t + 800: return 7
        return 4

    def orient_score(o):
        if not o: return 2
        o = o.replace(" ", "")
        if "南" in o and "北" in o: return 8
        if o in ("南", "东南"): return 8
        if o in ("东", "西南"): return 5
        return 2

    def layout_room_score(layout):
        """户型分：2室/3室→10；1室→7；4室→5；5室+→3（按 layout 首数字解析）。"""
        m = re.match(r"(\d+)", str(layout or ""))
        rooms = int(m.group(1)) if m else 0
        if rooms in (2, 3): return 10
        if rooms == 1: return 7
        if rooms == 4: return 5
        return 3

    def area_score(area):
        if not area: return 4
        if 60 <= area <= 120: return 8
        if 120 < area <= 150: return 5
        return 4

    results = []
    for it in items:
        rent, area = it["monthly_rent_yuan"], it["area_sqm"]
        up = rent / area if area else 999
        # A 性价比 45
        a = 45 if up <= p30 else 35 if up <= p50 else 22 if up <= p70 else 12 if up <= p90 else 5
        mkey = re.match(r"(\d+)", str(it.get("layout") or ""))
        mean_key = (it["community"], mkey.group(1) if mkey else "?")
        if rent > comm_mean.get(mean_key, rent) * 1.15:
            a = max(0, a - 5)  # 同小区同户型偏贵
        # B 基本面 35
        b = orient_score(it.get("orientation")) + layout_room_score(it.get("layout")) + area_score(area)
        # 整租(4)/合租(2)：SKILL 评分表；合租运行(--rent-type 002)时按合租计
        b += 2 if args.rent_type == "002" else 4
        b += 5 if it["del_type"] == 2 else 2  # 普租/托管
        # C 价格信号 10
        c = price_signal(rent)
        # D 可确认性 10
        has_title, has_plan = bool(it.get("title_image_url")), bool(it.get("floor_plan_image_url"))
        d = 10 if (has_title and has_plan) else 7 if (has_title or has_plan) else 0
        results.append({**it, "A": a, "B": b, "C": c, "D": d,
                        "score": a + b + c + d, "has_title": has_title, "has_plan": has_plan})
    results.sort(key=lambda r: -r["score"])
    json.dump(results, open(os.path.join(out, "scored.json"), "w", encoding="utf-8"), ensure_ascii=False)
    pool1 = [r for r in results if r["score"] >= args.min_score and r["has_title"]]
    json.dump(pool1, open(os.path.join(out, "pool1.json"), "w", encoding="utf-8"), ensure_ascii=False)
    print(f"[score] 完成: 池 {len(results)} 套, 过筛(≥{args.min_score}且有封面) {len(pool1)} 套")


# ---------- 阶段: covers ----------
def stage_covers(args, out):
    pool1 = json.load(open(os.path.join(out, "pool1.json"), encoding="utf-8"))
    cdir = os.path.join(out, "covers")
    os.makedirs(cdir, exist_ok=True)
    print(f"[covers] {len(pool1)} 套封面 sheet 拼图")
    urls = []
    for r in pool1:
        u = public_url(r.get("title_image_url"))
        r["_cover"] = u
        urls.append((u, os.path.join(cdir, f"cover_{r['listing_id']}.jpg")))
    with ThreadPoolExecutor(max_workers=8) as ex:
        ok = list(ex.map(lambda p: dl(*p), urls))
    print(f"  封面下载 {sum(1 for p in ok if p)}/{len(pool1)}")

    from PIL import Image, ImageDraw, ImageFont
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 22)
        font_s = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 18)
    except Exception:
        font = font_s = ImageFont.load_default()
    SHEET, cols, rows = 16, 4, 4
    cell_w, cell_h = 480, 400
    for s in range(0, len(pool1), SHEET):
        batch = pool1[s:s + SHEET]
        sheet = Image.new("RGB", (cols * cell_w, rows * cell_h), (20, 24, 35))
        draw = ImageDraw.Draw(sheet)
        for i, r in enumerate(batch):
            cx, cy = (i % cols) * cell_w, (i // cols) * cell_h
            ip = os.path.join(cdir, f"cover_{r['listing_id']}.jpg")
            try:
                img = Image.open(ip).convert("RGB").resize((cell_w, cell_h - 70), Image.LANCZOS)
                sheet.paste(img, (cx, cy))
            except Exception:
                draw.rectangle([cx, cy, cx + cell_w, cy + cell_h - 70], fill=(60, 64, 80))
                draw.text((cx + 20, cy + 40), "无图", fill=(255, 120, 120), font=font)
            draw.text((cx + 12, cy + cell_h - 64),
                      f"[{s+i+1:02d}] {r['community']} {int(r['monthly_rent_yuan'])}元 {r['area_sqm']:.0f}㎡ {r.get('orientation','')}",
                      fill=(255, 255, 255), font=font)
            draw.text((cx + 12, cy + cell_h - 38),
                      f"{r.get('layout','')} {'托管' if r['del_type']==5 else '普租'} 数据分{r['score']}",
                      fill=(160, 200, 255), font=font_s)
            draw.rectangle([cx, cy, cx + cell_w, cy + cell_h], outline=(70, 80, 100), width=1)
        sheet.save(os.path.join(cdir, f"sheet_{s//SHEET+1:02d}.png"))
    json.dump([{"sheet_no": i + 1, "listing_id": r["listing_id"], "community": r["community"]}
               for i, r in enumerate(pool1)],
              open(os.path.join(cdir, "sheet_map.json"), "w", encoding="utf-8"), ensure_ascii=False)
    print(f"[covers] 完成: {(len(pool1)+SHEET-1)//SHEET} 张 sheet")


# ---------- 阶段: prospect ----------
def stage_prospect(args, out):
    pool1 = json.load(open(os.path.join(out, "pool1.json"), encoding="utf-8"))
    pool1 = [r for r in pool1 if r["listing_id"] not in args.exclude_ids]
    pool1.sort(key=lambda r: -r["score"])
    top = pool1[:args.top]  # 托管不调普租 prospect(对其恒空)；托管实勘在 fullhouse 阶段走 tuoguan 通道
    pdir = os.path.join(out, "prospects")
    os.makedirs(pdir, exist_ok=True)
    n_pu = sum(1 for r in top if r["del_type"] == 2)
    n_tg = sum(1 for r in top if r["del_type"] == 5)
    print(f"[prospect] top{args.top} 中普租 {n_pu} 套拉全屋实勘，托管 {n_tg} 套跳过(普租 prospect 对托管无效，实勘在 fullhouse 走 tuoguan)")

    def fetch(r):
        if r["del_type"] == 5:
            return r, "托管·fullhouse 阶段走 tuoguan（redirect 解析）"
        fp = os.path.join(pdir, f"{r['listing_id']}.json")
        if os.path.exists(fp):
            return r, "已有"
        d = get(f"/api/v1/listings/rental/{r['listing_id']}/prospect")
        if d is not None:
            json.dump(d, open(fp, "w", encoding="utf-8"), ensure_ascii=False)
            return r, f"照片{len(d.get('photos') or [])}张"
        return r, "拉取失败"

    with ThreadPoolExecutor(max_workers=5) as ex:
        for i, (r, msg) in enumerate(ex.map(fetch, top), 1):
            print(f"  [{i}/{len(top)}] {r['listing_id']} {r['community']} {msg}", flush=True)
    print("[prospect] 完成")


def pick_room_photos(photos, limit=7, key="room_name"):
    """每个房间类型至少 1 张（保持输入顺序），剩余名额按原顺序回填至 limit 张。"""
    picked, seen, picked_ids = [], set(), set()
    for p in photos:
        k = p.get(key)
        if k not in seen:
            picked.append(p)
            seen.add(k)
            picked_ids.add(id(p))
    for p in photos:
        if len(picked) >= limit:
            break
        if id(p) not in picked_ids:
            picked.append(p)
            picked_ids.add(id(p))
    return picked


# ---------- 阶段: fullhouse ----------
def stage_fullhouse(args, out):
    """分块拼图：默认全量；--chunk N 时每轮只拼未拼的前 N 套（断点续跑）。
    agent 流程：跑一轮 → 立即对本轮全屋图全并行视觉评分 → 再跑下一轮。"""
    pool1 = json.load(open(os.path.join(out, "pool1.json"), encoding="utf-8"))
    pool1 = [r for r in pool1 if r["listing_id"] not in args.exclude_ids]
    pool1.sort(key=lambda r: -r["score"])
    top = pool1[:args.top]  # 普租读本地 prospect；托管必须走已回链的 tuoguan 实勘
    pdir, fdir = os.path.join(out, "prospects"), os.path.join(out, "fullhouse")
    os.makedirs(fdir, exist_ok=True)
    todo = [r for r in top if not os.path.exists(os.path.join(fdir, f"full_{r['listing_id']}.png"))]
    if args.chunk:
        todo = todo[:args.chunk]
    print(f"[fullhouse] 待拼 {len(todo)} 套（本轮），共 {len(top)} 套（含托管{sum(1 for r in top if r['del_type']==5)}）")

    # 托管详情优先走与前端点击一致的 getRedirectUrl（house→cell），并用详情
    # 回链校验；仅对 redirect 解析失败的房源用待出租库存兜底。不能把租赁列表
    # 的 house_del_code 当作 cell_code，也不能静默退回封面。
    tg_rows = [r for r in todo if r["del_type"] == 5]
    if tg_rows:
        resolve_tuoguan_rows(tg_rows, out, None)
        unresolved = [
            r for r in tg_rows
            if not r.get("_tuoguan") or not (r["_tuoguan"].get("prospects") or [])
        ]
        if unresolved:
            inventory = load_tuoguan_inventory(out)
            if inventory is not None:
                resolve_tuoguan_rows(unresolved, out, inventory)
        unresolved = [
            r for r in tg_rows
            if not r.get("_tuoguan") or not (r["_tuoguan"].get("prospects") or [])
        ]
        if unresolved:
            # 库存可能在上次运行后发生变化；只在首次匹配失败时刷新一次。
            fresh_inventory = load_tuoguan_inventory(out, refresh=True)
            if fresh_inventory is not None:
                resolve_tuoguan_rows(unresolved, out, fresh_inventory)
        unresolved = [
            r for r in tg_rows
            if not r.get("_tuoguan") or not (r["_tuoguan"].get("prospects") or [])
        ]
        n_hit = len(tg_rows) - len(unresolved)
        print(f"[fullhouse] 托管 {len(tg_rows)} 套，详情回链并命中实勘 {n_hit} 套，失败 {len(unresolved)} 套")
        if unresolved:
            errors = {
                str(r["listing_id"]): r.get("_tuoguan_source", "未知失败")
                for r in unresolved
            }
            json.dump(
                errors,
                open(os.path.join(out, "tuoguan_resolution_errors.json"), "w", encoding="utf-8"),
                ensure_ascii=False,
            )
            raise RuntimeError(
                "托管实勘未完成，已停止全屋精审：" + ",".join(errors)
            )

    tasks = []
    for r in todo:
        lid = r["listing_id"]
        if r["del_type"] == 5:
            tg = r.get("_tuoguan") or {}
            tg_photos = tg.get("prospects") or []
            tg_plans = tg.get("house_type_images") or []
            if tg_photos:
                for i, p in enumerate(pick_room_photos(tg_photos, key="name")):
                    tasks.append((
                        f"tg_{lid}_{i}.jpg",
                        public_url(p.get("url")),
                        os.path.join(fdir, f"tg_{lid}_{i}.jpg"),
                    ))
                for i, u in enumerate(tg_plans):
                    tasks.append((
                        f"tgplan_{lid}_{i}.jpg",
                        public_url(u),
                        os.path.join(fdir, f"tgplan_{lid}_{i}.jpg"),
                    ))
            continue
        pf = os.path.join(pdir, f"{lid}.json")
        if not os.path.exists(pf):
            continue
        data = json.load(open(pf, encoding="utf-8"))
        room_order = {"客厅": 0, "卧室": 1, "厨房": 2, "卫生间": 3, "阳台": 4}
        ph = sorted(data.get("photos") or [],
                    key=lambda p: (0 if p.get("image_type") == "TITLE" else 1,
                                   room_order.get(p.get("room_name", ""), 9)))
        for i, p in enumerate(pick_room_photos(ph)):
            tasks.append((f"raw_{lid}_{i}.jpg", public_url(p.get("url")), os.path.join(fdir, f"raw_{lid}_{i}.jpg")))
        if data.get("floor_plan_url"):
            tasks.append((f"plan_{lid}.jpg", public_url(data.get("floor_plan_url")), os.path.join(fdir, f"plan_{lid}.jpg")))
    with ThreadPoolExecutor(max_workers=5) as ex:  # 下载并发匹配详情查询并发(5)
        list(ex.map(lambda t: dl(t[1], t[2]), tasks))

    from PIL import Image, ImageDraw, ImageFont
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 20)
    except Exception:
        font = ImageFont.load_default()
    cols, cell_w, cell_h = 4, 520, 390
    done_ids = []
    for r in todo:
        lid = r["listing_id"]
        header = f"{r['community']} | {int(r['monthly_rent_yuan'])}元/月 | {r.get('layout','')} | {r['area_sqm']:.0f}㎡ | {r.get('orientation','')} | 数据分{r['score']}"
        imgs = []
        if r["del_type"] == 5:
            tg = r.get("_tuoguan") or {}
            tg_photos = tg.get("prospects") or []
            tg_plans = tg.get("house_type_images") or []
            if tg_photos:
                header += f" | 托管·tuoguan 实勘{len(tg_photos)}张"
                for i, p in enumerate(pick_room_photos(tg_photos, key="name")):
                    ip = os.path.join(fdir, f"tg_{lid}_{i}.jpg")
                    if os.path.exists(ip):
                        imgs.append((p.get("name") or "实勘", ip))
                for i, _ in enumerate(tg_plans):
                    ip = os.path.join(fdir, f"tgplan_{lid}_{i}.jpg")
                    if os.path.exists(ip):
                        imgs.append(("户型图", ip))
        else:
            pf = os.path.join(pdir, f"{lid}.json")
            if not os.path.exists(pf):
                continue
            data = json.load(open(pf, encoding="utf-8"))
            room_order = {"客厅": 0, "卧室": 1, "厨房": 2, "卫生间": 3, "阳台": 4}
            ph = sorted(data.get("photos") or [],
                        key=lambda p: (0 if p.get("image_type") == "TITLE" else 1,
                                       room_order.get(p.get("room_name", ""), 9)))
            for i, p in enumerate(pick_room_photos(ph)):
                ip = os.path.join(fdir, f"raw_{lid}_{i}.jpg")
                if os.path.exists(ip):
                    imgs.append((p.get("room_name") or "房间", ip))
            pp = os.path.join(fdir, f"plan_{lid}.jpg")
            if data.get("floor_plan_url") and os.path.exists(pp):
                imgs.append(("户型图", pp))
        if not imgs:
            continue
        rows = (len(imgs) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * cell_w, 60 + rows * cell_h), (15, 20, 30))
        draw = ImageDraw.Draw(sheet)
        draw.rectangle([0, 0, cols * cell_w, 60], fill=(25, 32, 48))
        draw.text((16, 16), header, fill=(255, 255, 255), font=font)
        for i, (label, ip) in enumerate(imgs):
            cx, cy = (i % cols) * cell_w, 60 + (i // cols) * cell_h
            try:
                img = Image.open(ip).convert("RGB").resize((cell_w, cell_h - 44), Image.LANCZOS)
                sheet.paste(img, (cx, cy))
            except Exception:
                draw.rectangle([cx, cy, cx + cell_w, cy + cell_h - 44], fill=(60, 64, 80))
            draw.rectangle([cx, cy + cell_h - 44, cx + cell_w, cy + cell_h], fill=(30, 38, 56))
            draw.text((cx + 12, cy + cell_h - 36), label, fill=(140, 220, 255), font=font)
            draw.rectangle([cx, cy, cx + cell_w, cy + cell_h], outline=(60, 70, 90), width=1)
        sheet.save(os.path.join(fdir, f"full_{lid}.png"))
        done_ids.append(lid)
    print(f"[fullhouse] 本轮完成 {len(done_ids)} 套: {','.join(done_ids) if done_ids else '无'}")
    if todo and not done_ids:
        print("[fullhouse] 提示: 本轮 todo 但无输出，检查 prospect JSON/列表行图片字段是否缺失")


# ---------- 阶段: tags ----------
def extract_tags(info):
    tags = []
    prop = info.get("property_info") or {}
    if str(prop.get("elevator")) in ("有", "True", "true", "1"):
        tags.append("电梯")
    wt, et = prop.get("water_type"), prop.get("electric_type")
    if wt and "民水" in str(wt) and et and "民电" in str(et):
        tags.append("民水民电")
    elif wt and "民水" in str(wt):
        tags.append("民水")
    if str(prop.get("gas")) in ("有", "True", "true", "1"):
        tags.append("燃气")
    for mod in (info.get("maintain") or {}).get("modules") or []:
        for f in mod.get("fields") or []:
            name, val = f.get("name") or "", f.get("display_value") or ""
            if "装修" in name and val and val != "--":
                tags.append(str(val))
            if "入住" in name and "随时" in str(val):
                tags.append("随时入住")
    labels = info.get("labels") or []
    if "VR" in str(labels):
        tags.append("VR")
    if "学区" in str(labels):
        tags.append("学区")
    seen, out = set(), []
    for t in tags:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out[:4]


def extract_tuoguan_tags(detail):
    """Extract customer-facing tags from the tuoguan detail response."""
    if not isinstance(detail, dict):
        return [], None
    tags = []
    if detail.get("vr_url"):
        tags.append("VR")
    if detail.get("can_live_time"):
        tags.append("随时入住")
    key_desc = detail.get("key_desc") or ""
    if "智能门锁" in str(key_desc) or detail.get("has_smart_key"):
        tags.append("智能门锁")
    viewing = detail.get("viewing_house_time") or ""
    if "随时" in str(viewing):
        tags.append("随时可看")

    floor_desc = detail.get("floor_type")
    if floor_desc and detail.get("total_floor"):
        floor_desc = f"{floor_desc}/{detail.get('total_floor')}"
    return tags[:4], floor_desc


def stage_tags(args, out):
    pool1 = json.load(open(os.path.join(out, "pool1.json"), encoding="utf-8"))
    pool1 = [r for r in pool1 if r["listing_id"] not in args.exclude_ids]
    pool1.sort(key=lambda r: -r["score"])
    # Visual scores must participate before the final-N cut.  Otherwise a
    # data-score rank 16 candidate can never enter the delivered top 15.
    vpath = args.vision or os.path.join(out, "vision_scores.json")
    visual = {}
    if os.path.exists(vpath):
        visual = json.load(open(vpath, encoding="utf-8"))
    ranked = pool1[:args.top]
    for r in ranked:
        r["_rank_score"] = r["score"] + visual.get(str(r["listing_id"]), 0)
    ranked.sort(key=lambda r: -r["_rank_score"])
    final = ranked[:args.final]
    ddir = os.path.join(out, "details")
    os.makedirs(ddir, exist_ok=True)
    print(f"[tags] 最终名单 top{args.final}，5 套并发拉详情+house-info 提取特色标签")

    tg_inventory = None
    errors = {}

    # 托管解析两段式（避免多线程重复加载库存）：先全量走 redirect（与前端点击
    # 一致的 house→cell 解析），仍有失败再一次性加载待出租库存候选兜底。
    tg_rows = [r for r in final if r["del_type"] == 5]
    if tg_rows:
        resolve_tuoguan_rows(tg_rows, out, None)
        pending = [
            r for r in tg_rows
            if not r.get("_tuoguan") or not (r["_tuoguan"].get("prospects") or [])
        ]
        if pending:
            tg_inventory = load_tuoguan_inventory(out)
            if tg_inventory is not None:
                resolve_tuoguan_rows(pending, out, tg_inventory)

    def fetch(r):
        lid = r["listing_id"]
        if r["del_type"] == 5:
            tg = r.get("_tuoguan")
            if not tg or not (tg.get("prospects") or []):
                errors[str(lid)] = r.get("_tuoguan_source", "未知失败")
                r["tags"], r["floor_desc"] = [], None
            else:
                r["tags"], r["floor_desc"] = extract_tuoguan_tags(tg)
            return r
        dp, hp = os.path.join(ddir, f"detail_{lid}.json"), os.path.join(ddir, f"info_{lid}.json")
        if not os.path.exists(dp):
            d = get(f"/api/v1/listings/rental/{lid}")
            if d is not None:
                json.dump(d, open(dp, "w", encoding="utf-8"), ensure_ascii=False)
        if not os.path.exists(hp):
            h = get(f"/api/v1/listings/rental/{lid}/house-info")
            if h is not None:
                json.dump(h, open(hp, "w", encoding="utf-8"), ensure_ascii=False)
        try:
            info = json.load(open(hp, encoding="utf-8"))
            r["tags"] = extract_tags(info)
        except Exception:
            r["tags"] = []
        try:
            det = json.load(open(dp, encoding="utf-8"))
            r["floor_desc"] = det.get("floor_desc")
        except Exception:
            r["floor_desc"] = None
        return r

    with ThreadPoolExecutor(max_workers=5) as ex:
        for i, r in enumerate(ex.map(fetch, final), 1):
            print(f"  [{i}/{args.final}] {r['listing_id']} {r['community']} 标签:{r['tags']} 楼层:{r['floor_desc']}", flush=True)
    if errors:
        json.dump(
            errors,
            open(os.path.join(out, "tuoguan_resolution_errors.json"), "w", encoding="utf-8"),
            ensure_ascii=False,
        )
        raise RuntimeError("托管实勘未完成，停止生成推荐：" + ",".join(errors))
    for r in final:
        r.pop("_rank_score", None)
    json.dump(final, open(os.path.join(out, f"final{args.final}.json"), "w", encoding="utf-8"), ensure_ascii=False)
    print("[tags] 完成")


# ---------- 阶段: poster ----------
def stage_poster(args, out):
    final = json.load(open(os.path.join(out, f"final{args.final}.json"), encoding="utf-8"))
    # 视觉分合并
    vpath = args.vision or os.path.join(out, "vision_scores.json")
    visual = {}
    if os.path.exists(vpath):
        visual = json.load(open(vpath, encoding="utf-8"))
        print(f"[poster] 视觉分 {len(visual)} 套")
    for r in final:
        r["final_score"] = r["score"] + visual.get(r["listing_id"], 0)
    final.sort(key=lambda r: -r["final_score"])
    final = final[:args.final]

    items = [{
        "listing_id": r["listing_id"], "community": r["community"],
        "layout": r.get("layout"), "area_sqm": r["area_sqm"],
        "monthly_rent_yuan": r["monthly_rent_yuan"], "orientation": r.get("orientation"),
        "floor_desc": r.get("floor_desc"), "del_type": r["del_type"],
        "title_image_url": r.get("title_image_url"), "floor_plan_image_url": r.get("floor_plan_image_url"),
        "tags": r.get("tags") or [], "score": r["final_score"],
    } for r in final]
    payload = {
        "title": args.poster_title or f"{args.location} 附近 · 精选",
        "subtitle": args.poster_subtitle or f"整租 · {args.price or '价格'} · 精审 Top {args.final}",
        "note": "数据来源：贝壳平台",
        "theme": "dark", "show_listing_id": False, "items": items,
    }
    pj = os.path.join(out, "poster_payload.json")
    json.dump(payload, open(pj, "w", encoding="utf-8"), ensure_ascii=False)

    skill_dir = os.path.join(os.path.expanduser("~"), "AppData/Local/hermes/skills/productivity/listing-poster")
    poster_script = os.path.join(skill_dir, "scripts", "listing_poster.py")
    pout = os.path.join(out, "poster")
    cmd = (f'"{sys.executable}" "{poster_script}" "{pj}" --theme dark --scale 1 --out "{pout}"'
           if sys.executable.lower().endswith("python313") or "python313" in sys.executable.lower()
           else f'C:/Python313/python.exe "{poster_script}" "{pj}" --theme dark --scale 1 --out "{pout}"')
    print("[poster] 渲染:", cmd)
    os.system(cmd)


# ---------- main ----------
def main():
    ap = argparse.ArgumentParser(description="租赁房源查询通用流水线")
    ap.add_argument("--location", required=True, help="位置/地标/商圈名")
    ap.add_argument("--radius", type=int, default=1000, help="半径米(默认1000)")
    ap.add_argument("--price", default=None, help='价格段 "min:max" 如 1000:2500')
    ap.add_argument("--rooms", type=int, nargs="*", default=None, help="室数，如 --rooms 1")
    ap.add_argument("--rent-type", default=None, choices=["001", "002", None], help="整租001/合租002/不限制")
    ap.add_argument("--target-price", type=int, default=None, help="客户目标价(价格信号主流段中心)")
    ap.add_argument("--bedroom-amount", default=None, help="condition_filters.bedroomAmount")
    ap.add_argument("--stage", default="all",
                    choices=["all", "collect", "score", "covers", "prospect", "fullhouse", "tags", "poster"])
    ap.add_argument("--min-score", type=int, default=70, help="数据分粗筛阈值(默认70)")
    ap.add_argument("--top", type=int, default=50, help="prospect/fullhouse 精审上限(默认50)")
    ap.add_argument("--chunk", type=int, default=0, help="fullhouse 每轮拼图数(默认0=全量；>0 时每轮只拼未拼的前 N 套，拼完立即评分后跑下一轮)")
    ap.add_argument("--final", type=int, default=15, help="最终交付数(默认15)")
    ap.add_argument("--vision", default=None, help="vision_scores.json 路径")
    ap.add_argument("--exclude", default=None,
                    help='封面速评淘汰名单：逗号分隔 listing_id，或 "@文件路径"(每行一个 id)；prospect/fullhouse/tags/poster 均过滤')
    ap.add_argument("--poster-title", default=None)
    ap.add_argument("--poster-subtitle", default=None)
    ap.add_argument("--out", default=None, help="输出目录(默认 ~/listing_analysis/<slug>)")
    args = ap.parse_args()

    if args.price:
        m = re.match(r"(\d*):(\d*)$", args.price.strip())
        if not m:
            sys.exit(f"--price 格式应为 min:max，收到 {args.price!r}")
        args.price_min = int(m.group(1)) if m.group(1) else None
        args.price_max = int(m.group(2)) if m.group(2) else None
        if args.price_min is not None and args.price_max is not None and args.price_min > args.price_max:
            sys.exit(f"--price 区间倒挂（{args.price_min}:{args.price_max}）")
    else:
        args.price_min = args.price_max = None
    args.rental_modes = {"001": ["whole_rent"], "002": ["shared_rent"]}.get(args.rent_type)
    if not args.bedroom_amount and args.rooms and len(args.rooms) == 1:
        args.bedroom_amount = str(args.rooms[0])

    # 封面速评淘汰名单：--exclude "id1,id2" 或 --exclude "@file"
    args.exclude_ids = set()
    if args.exclude:
        src = args.exclude
        if src.startswith("@"):
            with open(src[1:], encoding="utf-8") as f:
                args.exclude_ids = {ln.strip() for ln in f if ln.strip()}
        else:
            args.exclude_ids = {x.strip() for x in src.split(",") if x.strip()}
        print(f"封面速评淘汰: {len(args.exclude_ids)} 套")

    slug = re.sub(r"[^\w\u4e00-\u9fff]+", "_", args.location)
    out = args.out or os.path.join(os.path.expanduser("~"), "listing_analysis", f"{slug}_{args.radius}m")
    os.makedirs(out, exist_ok=True)
    print(f"输出目录: {out}")

    stages = ["collect", "score", "covers", "prospect", "fullhouse", "tags", "poster"]
    if args.stage != "all":
        stages = [args.stage]
    for s in stages:
        {"collect": stage_collect, "score": stage_score, "covers": stage_covers,
         "prospect": stage_prospect, "fullhouse": stage_fullhouse,
         "tags": stage_tags, "poster": stage_poster}[s](args, out)


if __name__ == "__main__":
    main()
