"""房源海报/拼图生成器 v5：HTML/CSS 模板 + Playwright 无头渲染导出 PNG。

v5（2026-08-15 整版替换定稿）客户向重设计，相对 v4 的变化：
- 卡片信息权重重排：小区名提到第一排左主位（粗体），价格右上彩色大字；
  买卖单价作为价格下方小字右对齐。
- 评分徽章去分数化：客户向只显示档位徽章（>=88 精选 / >=78 优选，
  score_label 可覆盖文案）；show_listing_id 内部交接模式才附带分数。
- TOP 1-3 金边框 + 金色编号角标，第 1 名另加 TOP 1 角标（浏览动线锚点）。
- 每卡新增 "✦ 一句话卖点" 行（payload.highlight 覆盖，否则按规则自动生成）。
- 特色标签硬上限 3 个（不再做像素预算估算）。
- 页眉右侧 "共 N 套 · 按综合性价比排序" + 报号提示；页脚 CTA 引导报号。
- 客户向（show_listing_id=false）note 含内部字样时整体替换为
  "数据来源：贝壳平台"（A+/内网/门店/维护人 命中即触发）。

保持不变：CLI 参数、payload 结构、三种 MCP 行形态归一化、CDN 尺寸后缀
（含 ! 指令剥离）、占位图兜底、listing_map.json 编号映射（报号唯一依据）、
light/dark 双主题、3 列等高网格。

用法：
    python scripts/listing_poster.py <payload.json> --theme dark
    python scripts/listing_poster.py - < <(cat payload.json)   # stdin

输出（默认 outputs/listing_poster_<时间戳>/）：
    - poster.png   海报（--scale 默认 1，微信交付；2x 仅大屏展示）
    - poster.html  渲染用的 HTML（调试/预览）
    - listing_map.json  编号↔房源映射（报号匹配唯一依据）

payload 结构：
    {
      "title": "万象城商圈 房源精选",        // 标题（必填）
      "subtitle": "套一 · 1000-2500元",      // 副标题筛选条件胶囊（可选）
      "note": "数据来源：贝壳平台",          // 页脚说明（可选）
      "theme": "dark",                      // light | dark（可选）
      "show_listing_id": false,             // 内部交接模式：卡片脚注编号+徽章带分数
      "items": [ ...房源字典数组... ]        // 必填
    }

items 支持三种原始 MCP 返回形态（自动识别，可混用）：
    1. 租赁列表行（rental_listing_search.items）
    2. 买卖列表行（sale_listing_search.items）
    3. 地图附近房源行（rental_map_nearby_search.result.items）

统一覆盖字段（优先级最高）：community / layout / area_text / orientation /
floor_text / price_primary / price_unit / price_sub / score / score_label /
tags / type_label / image_url / caption / highlight。
"""
from __future__ import annotations

import argparse
import base64
import html
import json
import re
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

try:  # Windows 控制台默认 cp1252：改为 UTF-8 输出中文并实时刷新
    sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
except Exception:  # noqa: BLE001
    pass

ROOT = Path(__file__).resolve().parent.parent

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

CDN_HOST = "img.ljcdn.com"
_SIZE_SUFFIX_RE = re.compile(r"\.\d+x(?:\.|$)")
_INSTRUCTION_RE = re.compile(r"!.*$")
_ROOM_PATTERN = re.compile(r"(\d+)室(\d*)[厅居]?(\d*)[卫]?")
_AREA_PATTERN = re.compile(r"(\d+(?:\.\d+)?)\s*㎡|(\d+(?:\.\d+)?)\s*平米")

# 客户向 note 内部字样防护：命中即整体替换为统一来源文案（内部交接模式不触发）
_INTERNAL_NOTE_RE = re.compile(r"A\+|内网|门店|维护人|房管电话")
_SAFE_NOTE = "数据来源：贝壳平台"

# --------------------------------------------------------------------------
# 主题变量（CSS 自定义属性）：只换配色，布局 CSS 共用一套
# --------------------------------------------------------------------------
_THEME_VARS = {
    "light": """
        :root {
          --bg: #eef2f7;
          --text: #0f172a;
          --muted: #64748b;
          --card-bg: #ffffff;
          --card-border: rgba(203, 213, 225, 0.9);
          --card-border-top: rgba(251, 191, 36, 0.85);
          --chip-bg: #f1f5f9;
          --chip-border: #e2e8f0;
          --panel-bg: #f8fafc;
          --panel-border: #eef2f7;
          --spec-text: #475569;
          --accent: #0f766e;
          --accent-bg: #f0fdfa;
          --accent-border: #99f6e4;
          --highlight: #64748b;
          --price-rent: #dc2626;
          --price-sale: #0f766e;
          --header-bg: #ffffff;
          --gold: #b45309;
          --shadow-card: 0 24px 48px -24px rgba(15, 23, 42, 0.28),
                         0 6px 16px -8px rgba(15, 23, 42, 0.10);
        }
    """,
    "dark": """
        :root {
          --bg: #0d1526;
          --text: #edf2fa;
          --muted: #93a4c0;
          --card-bg: #162238;
          --card-border: #27395a;
          --card-border-top: rgba(251, 191, 36, 0.55);
          --chip-bg: #1d2c47;
          --chip-border: #31456b;
          --panel-bg: #121d31;
          --panel-border: #243b58;
          --spec-text: #b9c6dd;
          --accent: #2dd4bf;
          --accent-bg: rgba(45, 212, 191, 0.14);
          --accent-border: rgba(45, 212, 191, 0.45);
          --highlight: #8fa3c4;
          --price-rent: #ff8a7a;
          --price-sale: #5eead4;
          --header-bg: #13223c;
          --gold: #fbbf24;
          --shadow-card: 0 18px 36px -20px rgba(0, 0, 0, 0.55);
        }
    """,
}

# 占位图：图片下载失败或缺失时的渐变插画
_PLACEHOLDER_SVG = (
    "<svg xmlns='http://www.w3.org/2000/svg' width='640' height='420'>"
    "<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>"
    "<stop offset='0' stop-color='#e2e8f0'/><stop offset='1' stop-color='#cbd5e1'/>"
    "</linearGradient></defs>"
    "<rect width='640' height='420' fill='url(#g)'/>"
    "<path d='M270 232 L320 190 L370 232 Z' fill='#94a3b8'/>"
    "<rect x='290' y='232' width='60' height='52' rx='5' fill='#94a3b8'/>"
    "<text x='320' y='322' font-family='sans-serif' font-size='20' fill='#64748b'"
    " text-anchor='middle'>暂无图片</text>"
    "</svg>"
)
PLACEHOLDER_DATA_URL = (
    "data:image/svg+xml;base64,"
    + base64.b64encode(_PLACEHOLDER_SVG.encode("utf-8")).decode("ascii")
)

_IMAGE_SIZES = (450, 750, 800, 1500)


def _load_payload(path_arg: str) -> dict:
    """从文件路径或 stdin（'-'）读取 JSON payload。"""
    if path_arg == "-":
        text = sys.stdin.read()
    else:
        path = Path(path_arg)
        if not path.exists():
            sys.exit(f"输入文件不存在：{path}")
        text = path.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        sys.exit(f"payload JSON 解析失败：{exc}")
    if not isinstance(data, dict):
        sys.exit("payload 必须是 JSON 对象")
    return data


def sanitize_note(note, internal: bool) -> str:
    """客户向 note 防护：含内部字样整体替换为统一来源文案。"""
    note = str(note or "")
    if internal or not note:
        return note
    if _INTERNAL_NOTE_RE.search(note):
        print(f"  note 含内部字样，已替换为「{_SAFE_NOTE}」：{note}")
        return _SAFE_NOTE
    return note


# --------------------------------------------------------------------------
# 图片：CDN 尺寸后缀 + 下载内嵌 data URL
# --------------------------------------------------------------------------
def cdn_suffix_url(url: str, size: int = 750) -> str:
    """img.ljcdn.com 原图直接请求 403，拼上公开尺寸后缀（.750x.jpg）才能下载。

    上游偶发残缺/完整 CDN 指令后缀（``!m_fill,l_dy`` / ``!m_fit,h_630,w_516,
    l_bk,f_jpg``）：必须先剥掉 ``!`` 及其后全部内容再拼尺寸后缀，否则组合
    形态返回 404（2026-08-15 实测 404）。
    """
    if CDN_HOST not in url:
        return url
    url = _INSTRUCTION_RE.sub("", url)
    if _SIZE_SUFFIX_RE.search(url):
        return url
    ext = ".png" if url.lower().split("?", 1)[0].endswith(".png") else ".jpg"
    return f"{url}.{size}x{ext}"


def _download(url: str, timeout: float) -> str | None:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        content = resp.read()
    ctype = (resp.headers.get("Content-Type") or "image/jpeg").split(";")[0].strip()
    return "data:%s;base64,%s" % (
        ctype or "image/jpeg",
        base64.b64encode(content).decode("ascii"),
    )


def fetch_image_data_url(url: str, size: int, timeout: float, retries: int = 2) -> str:
    """下载图片并返回 data URL；失败返回占位图（不中断整批渲染）。"""
    target = cdn_suffix_url(url, size)
    for attempt in range(retries + 1):
        try:
            return _download(target, timeout)
        except Exception:  # noqa: BLE001 - 网络抖动重试，最终落占位图
            if attempt == retries:
                print(f"  图片下载失败，使用占位图：{target}")
            continue
    return PLACEHOLDER_DATA_URL


# --------------------------------------------------------------------------
# 字段归一化：三种 MCP 原始形态 → 统一卡片模型
# --------------------------------------------------------------------------
def _fmt_area(value) -> str | None:
    try:
        num = float(value)
    except (TypeError, ValueError):
        return None
    return f"{num:g}㎡"


def _score_tier(score) -> tuple[str, str] | None:
    """评分 → (css 级别, 文案)。v5 客户向档位：>=88 精选 / >=78 优选。"""
    if score is None:
        return None
    try:
        value = float(score)
    except (TypeError, ValueError):
        return None
    if value >= 88:
        return ("high", "精选")
    if value >= 78:
        return ("good", "优选")
    return None


def _sale_layout(layout: str | None) -> str | None:
    """买卖 layout 形如 2-1-1-1（室-厅-卫-厨）→ 2室1厅1卫。"""
    if not layout:
        return None
    if "室" in layout or "厅" in layout:
        return layout
    parts = re.split(r"[-_]", str(layout))
    if len(parts) >= 3:
        return f"{parts[0]}室{parts[1]}厅{parts[2]}卫"
    return layout


def normalize_item(raw: dict) -> dict:
    """把任意形态的房源字典归一化为卡片字段。统一字段优先，其次按形态推断。"""
    def has(*keys) -> bool:
        return any(raw.get(k) is not None for k in keys)

    def take(*keys, default=None):
        for key in keys:
            if raw.get(key) is not None:
                return raw.get(key)
        return default

    # 统一覆盖字段（优先级最高）
    community = take("community", "community_name")
    layout = take("layout")
    area_text = take("area_text")
    orientation = take("orientation")
    floor_text = take("floor_text", "floor_desc")
    price_primary = take("price_primary")
    price_unit = take("price_unit")
    price_sub = take("price_sub")
    score = take("score", "quality_score")
    score_label = take("score_label")
    tags = take("tags", default=[])
    type_label = take("type_label")
    if not type_label:
        del_type = raw.get("del_type", raw.get("delType"))
        if del_type is not None:
            try:
                del_type = int(del_type)
            except (TypeError, ValueError):
                del_type = None
            type_label = {2: "普租", 5: "托管"}.get(del_type)
    image_url = take("image_url", "title_image_url", "surface_image_url")
    caption = take("caption", "listing_id")

    mode = "rent"
    if price_primary is None:
        if has("monthly_rent_yuan"):
            rent = raw.get("monthly_rent_yuan")
            price_primary = f"¥{float(rent):,.0f}"
            price_unit = price_unit or "/月"
        elif has("total_price_text", "total_price_yuan"):
            mode = "sale"
            total_text = raw.get("total_price_text")
            if total_text:
                price_primary = str(total_text)
            elif raw.get("total_price_yuan") is not None:
                price_primary = f"{float(raw['total_price_yuan']) / 10000:g}万"
            unit = raw.get("unit_price_yuan_per_sqm")
            if unit is not None:
                price_sub = price_sub or f"单价 {float(unit):,.0f}元/㎡"
        elif has("price_text"):
            price_primary = str(raw.get("price_text"))
            price_unit = price_unit or ""

    if community is None:
        if has("title"):
            title = str(raw.get("title") or "")
            # 标题形如「北京城建龙樾湾 1室1厅1卫 50.46㎡ 南 1600元/月」：
            # 从第一个房型/面积/价格片段处截断，尾部残余朝向字符一并去掉
            cut = re.search(
                r"\d+\s*室|\d+(?:\.\d+)?\s*(?:㎡|平米)|\d+(?:\.\d+)?\s*元/月", title
            )
            community = title[: cut.start()] if cut else title
            community = re.sub(r"[\s东南西北]+$", "", community).strip() or title
        elif has("resblock_name"):
            community = raw.get("resblock_name")
        else:
            community = take("display_name") or "—"

    if layout is None:
        raw_layout = raw.get("layout")
        if has("title"):
            m = _ROOM_PATTERN.search(str(raw.get("title") or ""))
            if m:
                rooms, parlors, toilets = m.group(1), m.group(2), m.group(3)
                layout = f"{rooms}室"
                if parlors:
                    layout += f"{parlors}厅"
                if toilets:
                    layout += f"{toilets}卫"
        elif raw_layout:
            layout = str(raw_layout)
    if mode == "sale" and layout and "室" not in layout and "厅" not in layout:
        layout = _sale_layout(layout)

    if area_text is None and raw.get("area_sqm") is not None:
        area_text = _fmt_area(raw.get("area_sqm"))
    if area_text is None and has("title"):
        m = _AREA_PATTERN.search(str(raw.get("title") or ""))
        if m:
            area_text = f"{m.group(1) or m.group(2)}㎡"

    if image_url is None:
        image_url = take("floor_plan_image_url", "house_frame_image_url")

    if tags is None:
        tags = []
    tags = [str(t) for t in tags if t]

    return {
        "community": str(community or "—"),
        "layout": layout,
        "area_text": area_text,
        "orientation": str(orientation) if orientation else None,
        "floor_text": str(floor_text) if floor_text else None,
        "price_primary": str(price_primary or "—"),
        "price_unit": price_unit,
        "price_sub": price_sub,
        "mode": mode,
        "score": score,
        "score_label": score_label,
        "tags": tags,
        "type_label": type_label,
        "image_url": image_url,
        "image_data_url": take("image_data_url"),
        "caption": str(caption) if caption else None,
    }


def _auto_highlight(raw: dict, item: dict) -> str | None:
    """一句话卖点自动生成（payload.highlight 优先）。只摘客户能感知的信号。"""
    if raw.get("highlight"):
        return str(raw["highlight"])
    parts: list[str] = []
    tags = [str(t) for t in (raw.get("tags") or [])]

    if item["mode"] == "rent":
        rent = raw.get("monthly_rent_yuan")
        try:
            if rent is not None and float(rent) <= 1600:
                parts.append(f"月租仅{float(rent):.0f}元")
            elif (raw.get("A") or 0) >= 45:
                parts.append("租金低于同户型板块分位")
        except (TypeError, ValueError):
            pass
    else:  # sale：税费/区位标签转卖点
        for tag, text in (
            ("满五唯一", "满五唯一 税费低"),
            ("满二", "满二"),
            ("地铁", "近地铁"),
            ("电梯", "有电梯"),
        ):
            if any(tag in t for t in tags):
                parts.append(text)
                break

    if "随时入住" in tags:
        parts.append("随时入住")
    if "民水民电" in tags:
        parts.append("民水民电")
    if not parts and any("精装" in t for t in tags):
        parts.append("精装")
    if not parts and item.get("orientation") in ("南", "东南", "南北"):
        parts.append(f"{item['orientation']}朝向采光稳定")
    return " · ".join(parts[:2]) or None


# --------------------------------------------------------------------------
# HTML/CSS 模板（v5 版式）
# --------------------------------------------------------------------------
_CSS = """
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
                   "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
      background: var(--bg);
      color: var(--text);
      padding: 34px 0 26px;
      display: flex;
      justify-content: center;
      -webkit-font-smoothing: antialiased;
    }

    .container { position: relative; z-index: 1; width: 100%; max-width: 1280px;
                 margin: 0 auto; padding: 0 24px; }

    .header {
      background: var(--header-bg);
      padding: 22px 28px;
      border-radius: 20px;
      margin-bottom: 24px;
      border: 1px solid var(--card-border);
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
    }
    .header-left { display: flex; align-items: center; gap: 14px; flex-wrap: wrap;
                   min-width: 0; }
    .brand-badge {
      background: linear-gradient(135deg, #0f766e, #14b8a6);
      color: #ffffff;
      font-size: 12px;
      font-weight: 800;
      letter-spacing: 1px;
      padding: 6px 14px;
      border-radius: 999px;
    }
    .header-title { font-size: 26px; font-weight: 800; white-space: nowrap; }
    .header-subtitle {
      font-size: 13px;
      color: var(--muted);
      background: var(--chip-bg);
      border: 1px solid var(--chip-border);
      padding: 5px 14px;
      border-radius: 999px;
      font-weight: 600;
      white-space: nowrap;
    }
    .header-right { text-align: right; white-space: nowrap; }
    .header-count { font-size: 15px; font-weight: 800; color: var(--gold); }
    .header-hint { font-size: 11.5px; color: var(--muted); margin-top: 3px; }

    .grid-container {
      display: grid;
      /* 固定每行 3 个房源 */
      grid-template-columns: repeat(3, 1fr);
      gap: 20px;
    }

    .house-card {
      background: var(--card-bg);
      border-radius: 18px;
      overflow: hidden;
      border: 1px solid var(--card-border);
      display: flex;
      flex-direction: column;
      box-shadow: var(--shadow-card);
    }
    /* TOP 1-3 金边框（浏览动线锚点） */
    .house-card.top { border-color: var(--card-border-top); }

    .card-image-wrapper {
      position: relative;
      width: 100%;
      /* 实勘照片为 4:3 横向构图：图片区域按原图比例展示，不裁切主体 */
      aspect-ratio: 4 / 3;
      background: var(--panel-bg);
      overflow: hidden;
    }
    .card-image { width: 100%; height: 100%; object-fit: cover; display: block; }

    /* 编号：图片区域左上角玻璃角标（报号用）；TOP1-3 金底 */
    .tag-number {
      position: absolute;
      top: 10px;
      left: 10px;
      background: rgba(10, 16, 30, 0.66);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      color: #ffffff;
      font-size: 13px;
      font-weight: 800;
      padding: 3px 10px;
      border-radius: 9px;
      border: 1px solid rgba(255, 255, 255, 0.28);
      font-variant-numeric: tabular-nums;
    }
    .tag-number.gold {
      background: linear-gradient(135deg, #b45309, #f59e0b);
      border-color: rgba(253, 230, 138, 0.7);
      color: #ffffff;
    }
    .tag-rank {
      position: absolute;
      top: 10px;
      right: 10px;
      font-size: 11px;
      font-weight: 800;
      color: #1f2937;
      background: linear-gradient(135deg, #fde68a, #fbbf24);
      padding: 3px 10px;
      border-radius: 999px;
      letter-spacing: 1px;
    }

    .card-content { padding: 13px 16px 14px; display: flex; flex-direction: column;
                    gap: 9px; }

    /* 第一排：小区名（左主位）+ 价格（右，租赁红/买卖青）；买卖单价小字 */
    .row-main { display: flex; align-items: baseline; gap: 10px; }
    .community {
      flex: 1; min-width: 0; font-size: 16px; font-weight: 800;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .price-group { white-space: nowrap; font-variant-numeric: tabular-nums;
                   text-align: right; }
    .price-amount {
      font-size: 22px;
      font-weight: 800;
      color: var(--price-rent);
      letter-spacing: -0.5px;
    }
    .price-amount.sale { color: var(--price-sale); }
    .price-unit { font-size: 12px; color: var(--muted); font-weight: 600; }
    .price-sub { font-size: 11px; color: var(--muted); font-weight: 600;
                 margin-top: 1px; }

    /* 第二排：户型 | 面积 | 朝向 | 楼层 */
    .row-spec {
      font-size: 12.5px;
      color: var(--spec-text);
      background: var(--panel-bg);
      border: 1px solid var(--panel-border);
      padding: 7px 12px;
      border-radius: 10px;
      display: flex;
      justify-content: center;
      gap: 8px;
      font-weight: 600;
      white-space: nowrap;
      overflow: hidden;
    }
    .divider { color: var(--chip-border); }

    /* 第三排：类型标签（最左）+ 特色标签（≤3）+ 档位徽章（右，不带分数） */
    .row-bottom { display: flex; align-items: center; gap: 6px; min-height: 25px; }
    .tags-row { display: flex; flex-wrap: nowrap; overflow: hidden; gap: 6px;
                min-width: 0; flex: 1; }
    .tag-chip {
      flex-shrink: 0;
      font-size: 11px;
      font-weight: 600;
      color: var(--muted);
      background: var(--chip-bg);
      border: 1px solid var(--chip-border);
      padding: 3px 9px;
      border-radius: 999px;
      white-space: nowrap;
    }
    .tag-chip.accent {
      color: var(--accent);
      background: var(--accent-bg);
      border-color: var(--accent-border);
    }
    .tag-type-chip {
      flex-shrink: 0;
      font-size: 11px;
      font-weight: 700;
      color: #ffffff;
      background: #1d4ed8;
      border: 1px solid rgba(96, 165, 250, 0.55);
      padding: 3px 9px;
      border-radius: 999px;
      white-space: nowrap;
    }
    .tag-type-chip.managed {
      background: #6d28d9;
      border-color: rgba(167, 139, 250, 0.55);
    }
    .tier-badge {
      flex-shrink: 0;
      font-size: 11px;
      font-weight: 800;
      color: #1f2937;
      background: linear-gradient(135deg, #5eead4, #2dd4bf);
      padding: 3px 10px;
      border-radius: 999px;
      white-space: nowrap;
    }
    .tier-badge.good { background: linear-gradient(135deg, #fde68a, #fbbf24); }

    /* 第四排：一句话卖点（可选，无则不渲染） */
    .row-highlight {
      font-size: 11.5px;
      color: var(--highlight);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      font-weight: 600;
    }
    .row-highlight::before { content: "\\2726  "; color: var(--accent); }

    .card-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 11px;
      color: var(--muted);
    }
    .caption { font-variant-numeric: tabular-nums; }

    .footer { margin-top: 24px; text-align: center; font-size: 12px;
              color: var(--muted); line-height: 1.8; }
    .footer .cta { color: var(--gold); font-weight: 700; }
"""


def _build_card(item: dict, index: int, show_listing_id: bool) -> str:
    """渲染一张房源卡片（v5 版式）。"""
    esc = html.escape
    serial = f"{index:02d}"
    top3 = index <= 3

    # 档位徽章：客户向不带分数（score_label 优先，其次按阈值）；
    # 有分但低于 78 且无 score_label → 不显示徽章
    tier_html = ""
    tier = item.get("score_label") or None
    tier_cls = ""
    if not tier:
        t = _score_tier(item.get("score"))
        if t:
            tier_cls, tier = t
    if tier:
        if not tier_cls:
            tier_cls = "high" if str(tier) in ("精选", "推荐") else "good"
        if show_listing_id and item.get("score") is not None:
            try:
                tier = f"★{int(float(item['score']))} {tier}"
            except (TypeError, ValueError):
                pass
        tier_html = f'<span class="tier-badge{"" if tier_cls == "high" else " good"}">{esc(str(tier))}</span>'

    image_src = item.get("image_data_url") or PLACEHOLDER_DATA_URL
    num_cls = "tag-number gold" if top3 else "tag-number"
    rank_html = '<span class="tag-rank">TOP 1</span>' if index == 1 else ""
    img_html = (
        '<div class="card-image-wrapper">'
        f'<img class="card-image" src="{image_src}" alt="房源照片">'
        f'<span class="{num_cls}">{serial}</span>{rank_html}'
        "</div>"
    )

    # 第一排：小区名（左主位）+ 价格（右）；买卖单价小字第二行
    price_cls = " sale" if item["mode"] == "sale" else ""
    unit_html = (
        f'<span class="price-unit">{esc(str(item["price_unit"]))}</span>'
        if item.get("price_unit")
        else ""
    )
    sub_html = (
        f'<div class="price-sub">{esc(item["price_sub"])}</div>'
        if item.get("price_sub")
        else ""
    )
    main_html = (
        '<div class="row-main">'
        f'<div class="community" title="{esc(item["community"])}">{esc(item["community"])}</div>'
        f'<div class="price-group"><span class="price-amount{price_cls}">{esc(item["price_primary"])}</span>'
        f"{unit_html}{sub_html}</div>"
        "</div>"
    )

    # 第二排：户型 | 面积 | 朝向 | 楼层（行始终渲染，保证卡片等高）
    spec_cells = [
        f"<span>{esc(str(item[key]))}</span>"
        for key in ("layout", "area_text", "orientation", "floor_text")
        if item.get(key)
    ]
    cells = '<span class="divider">|</span>'.join(spec_cells) or "<span>—</span>"
    secondary = f'<div class="row-spec">{cells}</div>'

    # 第三排：类型标签（最左，必须显示）+ 特色标签（≤3）+ 档位徽章（右）
    chips = []
    type_label = item.get("type_label")
    if type_label:
        managed = " managed" if "托管" in str(type_label) else ""
        chips.append(f'<span class="tag-type-chip{managed}">{esc(str(type_label))}</span>')
    for i, tag in enumerate(item["tags"][:3]):
        cls = "tag-chip accent" if i == 0 else "tag-chip"
        chips.append(f'<span class="{cls}">{esc(tag)}</span>')
    tags_html = f'<div class="tags-row">{"".join(chips)}</div>' if chips else ""
    bottom_html = f'<div class="row-bottom">{tags_html}{tier_html}</div>'

    highlight = _auto_highlight(item["_raw"], item)
    hl_html = f'<div class="row-highlight">{esc(highlight)}</div>' if highlight else ""

    footer_html = ""
    if show_listing_id and item.get("caption"):
        footer_html = (
            '<div class="card-footer">'
            f'<span class="caption">房源编号 {esc(item["caption"])}</span>'
            "</div>"
        )

    card_cls = "house-card top" if top3 else "house-card"
    return (
        f'<div class="{card_cls}">{img_html}'
        f'<div class="card-content">{main_html}{secondary}{bottom_html}{hl_html}{footer_html}</div>'
        "</div>"
    )


def build_html(payload: dict, theme: str, show_listing_id: bool) -> str:
    """组装完整 HTML 文档。"""
    esc = html.escape
    title = esc(str(payload.get("title") or "房源精选"))
    subtitle = payload.get("subtitle")
    subtitle_html = (
        f'<span class="header-subtitle">{esc(str(subtitle))}</span>' if subtitle else ""
    )
    items = payload.get("items") or []

    cards = []
    for index, raw in enumerate(items, start=1):
        try:
            item = normalize_item(raw)
        except Exception as exc:  # noqa: BLE001 - 单条异常不中断整批
            print(f"  第 {index} 条房源归一化失败，已跳过：{exc}")
            continue
        item["_raw"] = raw
        cards.append(_build_card(item, index, show_listing_id))

    note = sanitize_note(payload.get("note"), internal=show_listing_id)
    generated = datetime.now().strftime("%Y-%m-%d %H:%M")
    footer_note = " · ".join(part for part in (note, f"生成于 {generated}") if part)
    serial_range = f"01-{len(cards):02d}" if len(cards) > 1 else "01"

    css = _THEME_VARS.get(theme, _THEME_VARS["light"]) + _CSS
    return (
        "<!DOCTYPE html>\n"
        '<html lang="zh-CN">\n<head>\n<meta charset="UTF-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
        f"<title>{title}</title>\n<style>{css}</style>\n</head>\n<body>\n"
        '<div class="container">'
        '<header class="header">'
        '<div class="header-left">'
        '<span class="brand-badge">贝壳 · 好房精选</span>'
        f'<span class="header-title">{title}</span>'
        f"{subtitle_html}"
        "</div>"
        '<div class="header-right">'
        f'<div class="header-count">共 {len(cards)} 套 · 按综合性价比排序</div>'
        '<div class="header-hint">看中哪套，回复编号即可看详情</div>'
        "</div>"
        "</header>"
        f'<main class="grid-container">{"".join(cards)}</main>'
        f'<div class="footer">{esc(footer_note)}<br>'
        f'<span class="cta">回复编号 {serial_range}，立即发您该套详情与全屋实勘</span></div>'
        "</div>\n</body>\n</html>"
    )


def render_png(html_text: str, out_png: Path, width: int, scale: int) -> None:
    """Playwright 无头 Chromium 渲染整页截图（scale 可控，微信默认 1x）。"""
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        try:
            page = browser.new_page(
                viewport={"width": width, "height": 900}, device_scale_factor=scale
            )
            page.set_content(html_text, wait_until="load")
            # 等字体与内嵌图片全部就绪，避免截图出现未解码占位
            page.evaluate(
                """async () => {
                  await document.fonts.ready;
                  await Promise.all(Array.from(document.images).map(img =>
                    img.complete ? true :
                    new Promise(resolve => {
                      img.onload = resolve;
                      img.onerror = resolve;
                    })));
                }"""
            )
            page.wait_for_timeout(120)
            page.screenshot(path=str(out_png), full_page=True)
        finally:
            try:
                browser.close()
            except Exception:  # noqa: BLE001
                pass


def main() -> int:
    ap = argparse.ArgumentParser(description="房源海报生成器 v5：HTML/CSS 模板 + Playwright 渲染 PNG")
    ap.add_argument("payload", help="payload JSON 文件路径，或用 '-' 从 stdin 读取")
    ap.add_argument("--out", type=Path, default=None, help="输出目录（默认 outputs/listing_poster_<时间戳>）")
    ap.add_argument("--theme", choices=["light", "dark"], default="light", help="主题（默认 light）")
    ap.add_argument("--image-size", type=int, default=750, choices=_IMAGE_SIZES,
                    help="CDN 尺寸后缀（默认 750）")
    ap.add_argument("--no-download", action="store_true", help="不下载图片，全部用占位图")
    ap.add_argument("--timeout", type=float, default=15, help="单张图片下载超时秒数（默认 15）")
    ap.add_argument("--scale", type=int, default=1, help="导出缩放倍率（默认 1；微信传输场景够用，2x 体积约 3 倍仅大屏展示需要）")
    ap.add_argument("--width", type=int, default=1360, help="渲染视口宽度（默认 1360）")
    args = ap.parse_args()

    payload = _load_payload(args.payload)
    items = payload.get("items") or []
    if not isinstance(items, list) or not items:
        sys.exit("payload.items 必须是非空数组")

    theme = payload.get("theme") or args.theme
    show_listing_id = bool(payload.get("show_listing_id"))

    out_dir = args.out or (ROOT / "outputs" / f"listing_poster_{datetime.now():%Y%m%d_%H%M%S}")
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"[1/3] 归一化 {len(items)} 条房源数据")
    if args.no_download:
        for raw in items:
            raw["image_data_url"] = None
    else:
        pending = []
        for raw in items:
            item = normalize_item(raw)
            if item.get("image_url"):
                pending.append((raw, item["image_url"]))
        if pending:
            print(f"[2/3] 并行下载 {len(pending)} 张房源图片（.x{args.image_size} 公开后缀）")
            unique_urls = {url for _, url in pending}
            with ThreadPoolExecutor(max_workers=6) as pool:
                results = pool.map(
                    lambda u: fetch_image_data_url(u, args.image_size, args.timeout),
                    unique_urls,
                )
            cache = dict(zip(unique_urls, results))
            for raw, url in pending:
                raw["image_data_url"] = cache[url]

    html_text = build_html(payload, theme, show_listing_id)
    html_path = out_dir / "poster.html"
    html_path.write_text(html_text, encoding="utf-8")

    # 编号↔房源映射：编号 = 卡片渲染顺序（01..n），报号时凭 no 查 listing_id
    mapping = []
    for i, raw in enumerate(items, start=1):
        entry = {"no": i}
        for k, v in raw.items():
            if k in ("image_data_url", "_raw") or isinstance(v, (bytes, bytearray)):
                continue
            entry[k] = v
        mapping.append(entry)
    map_path = out_dir / "listing_map.json"
    map_path.write_text(json.dumps(mapping, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"编号映射已保存：{map_path}")

    print(f"[3/3] Playwright 无头渲染（{theme} 主题，固定 3 列，{args.scale}x）")
    png_path = out_dir / "poster.png"
    render_png(html_text, png_path, args.width, args.scale)

    print(f"海报已生成：{png_path}")
    print(f"HTML 预览：{html_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
