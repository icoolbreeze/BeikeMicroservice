"""listing_detail_poster.py v5 冒烟测试：hero + 8 格规格 + 两列实勘 + 户型图收尾。

运行（skill 目录）：
    env -u PYTHONPATH C:/Python313/python.exe -m pytest scripts/tests/ -q
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent.parent
SCRIPTS = ROOT / "scripts"
POSTER = SCRIPTS / "listing_detail_poster.py"
PY = Path(r"C:\Python313\python.exe")

DEMO_PAYLOAD = {
    "theme": "dark",
    "show_listing_id": True,  # 内部模式：显示房源编号与分数（客户向默认 false）
    "detail": {
        "listing_id": "TEST0001",
        "community": "测试小区A",
        "layout": "2室1厅1卫",
        "area_sqm": 66.47,
        "monthly_rent_yuan": 1400,
        "orientation": "东",
        "floor_desc": "中楼层",
        "total_floors": 16,
        "listed_days": 2,
        "house_grade": "B",
        "maintain_org": "德佑-测试店",
        "source": "网络端口",
        "has_key": False,
        "del_status_text": "有效",
    },
    "prospect": {
        "photos": [
            {"url": "https://img.ljcdn.com//110000-inspection/t1.jpg",
             "room_name": "客厅", "image_type": "TITLE"},
            {"url": "https://img.ljcdn.com//110000-inspection/r1.jpg",
             "room_name": "卧室", "image_type": "REAL"},
            {"url": "https://img.ljcdn.com//110000-inspection/k1.jpg",
             "room_name": "厨房", "image_type": "REAL"},
        ],
        "floor_plan_url": "https://img.ljcdn.com//hdic-frame/fp1.jpg",
    },
    "score": 92,
    "score_label": "推荐",
    "tags": ["电梯房"],
}


@pytest.fixture()
def rendered(tmp_path: Path) -> Path:
    payload = tmp_path / "payload.json"
    payload.write_text(json.dumps(DEMO_PAYLOAD, ensure_ascii=False), encoding="utf-8")
    out = tmp_path / "out"
    proc = subprocess.run(
        [str(PY), str(POSTER), str(payload), "--no-download", "--out", str(out)],
        capture_output=True, text=True, timeout=120,
    )
    assert proc.returncode == 0, f"渲染失败:\n{proc.stdout}\n{proc.stderr}"
    return out


def test_detail_png_generated(rendered: Path) -> None:
    png, html = rendered / "detail.png", rendered / "detail.html"
    assert png.exists() and png.stat().st_size > 10_000, "PNG 未生成或过小"
    assert html.exists() and html.stat().st_size > 5_000, "HTML 未生成或过小"


def test_vertical_layout_and_sections(rendered: Path) -> None:
    """v5 竖向结构：封面 hero → 规格卡 → 其余照片两列网格 → 户型图全宽收尾。"""
    html = (rendered / "detail.html").read_text(encoding="utf-8")
    # TITLE 封面进 hero，其余 2 张进两列网格
    assert 'class="hero"' in html, "封面应渲染为 hero"
    assert html.count('class="photo-cell"') == 2, "2 张非封面照片进两列网格"
    assert html.count('class="photo-wide"') == 1, "1 张户型图全宽收尾"
    assert "客厅" in html and "卧室" in html and "厨房" in html
    assert "户型图" in html
    assert "TEST0001" in html, "内部模式应显示房源编号"
    # 顺序：hero 在规格卡之前，照片区在户型图之前（匹配 DOM 属性，避开 CSS 文本）
    assert html.index('class="hero"') < html.index('class="spec-grid"')
    assert html.index(">实勘照片") < html.index(">户型图<"), "户型图应在照片之后"


def test_detail_info_complete(rendered: Path) -> None:
    html = (rendered / "detail.html").read_text(encoding="utf-8")
    for token in ("¥1,400", "测试小区A", "2室1厅1卫", "66.47㎡", "东", "中楼层", "★92"):
        assert token in html, f"详情缺 {token}"
    assert html.count('class="spec-item"') == 8, "规格格应为 8 项（4 基础 + 4 生活）"
    for label in ("电梯", "入住", "水电气", "看房"):
        assert label in html, f"生活规格缺 {label}"


def test_internal_fields_not_rendered(rendered: Path) -> None:
    """v5 纪律：维护门店/来源/房屋等级/带看次数等内部字段一律不渲染。"""
    html = (rendered / "detail.html").read_text(encoding="utf-8")
    assert "德佑-测试店" not in html, "维护门店不应出现"
    assert "网络端口" not in html, "来源不应出现"


def test_customer_status_and_new_listing_chips(rendered: Path) -> None:
    """状态翻译成客户语言（有效→在租），挂牌≤3天出「3日内新上」。"""
    html = (rendered / "detail.html").read_text(encoding="utf-8")
    assert "在租" in html, "有效应翻译为在租"
    assert "3日内新上" in html, "listed_days=2 应出 3日内新上"


TUOGUAN_PAYLOAD = {
    "theme": "dark",
    "tuoguan": {
        "cell_code": "10612612882101",
        "house_del_code": "106126181022",
        "resblock_name": "环球汇广场",
        "house_type_desc": "1-0-1-1",
        "area_number": 42.05,
        "guide_price_yuan": 2000,
        "orientation": "东南",
        "floor_type": "低楼层",
        "total_floor": 40,
        "key_desc": "智能门锁",
        "manager": {"user_name": "陈蒋", "org_name": "川师区", "role_name": "房管人"},
        "tags": ["贝壳省心租·自营"],
        "prospects": [
            {"name": "01间-主卧", "url": "https://img.ljcdn.com/lease-image/house/c1.jpeg",
             "primary_flag": 1, "create_time": "2026-08-14 14:32:08"},
            {"name": "01间-厨房", "url": "https://img.ljcdn.com/lease-image/house/k1.jpeg",
             "primary_flag": 0, "create_time": "2026-08-14 14:32:08"},
        ],
        "house_type_images": [
            "https://img.ljcdn.com/hdic-frame/cyclops-fp1.jpg",
            "https://img.ljcdn.com/hdic-frame/cyclops-fp2.jpg",
        ],
    },
}


@pytest.fixture()
def tuoguan_rendered(tmp_path: Path) -> Path:
    payload = tmp_path / "payload_tg.json"
    payload.write_text(json.dumps(TUOGUAN_PAYLOAD, ensure_ascii=False), encoding="utf-8")
    out = tmp_path / "out_tg"
    proc = subprocess.run(
        [str(PY), str(POSTER), str(payload), "--no-download", "--out", str(out)],
        capture_output=True, text=True, timeout=120,
    )
    assert proc.returncode == 0, f"渲染失败:\n{proc.stdout}\n{proc.stderr}"
    return out


def test_tuoguan_payload_renders_prospects_and_floor_plans(tuoguan_rendered: Path) -> None:
    """托管详情（tuoguan_listing_get_detail 原始返回）应能直接渲染：
    primary_flag 封面进 hero，其余进网格，house_type_images 全部收尾。"""
    html = (tuoguan_rendered / "detail.html").read_text(encoding="utf-8")
    assert 'class="hero"' in html, "primary_flag 照片应进 hero"
    assert html.count('class="photo-cell"') == 1, "1 张非封面实勘进网格"
    assert html.count('class="photo-wide"') == 2, "house_type_images 全部收尾"
    # 封面（primary_flag=1）置顶：主卧（hero）在厨房（网格）之前
    assert html.index("01间-主卧") < html.index("01间-厨房")
    for token in ("¥2,000", "环球汇广场", "1-0-1-1", "42.05㎡", "东南", "低楼层",
                  "智能门锁", "陈蒋", "省心租房管"):
        assert token in html, f"托管详情缺 {token}"


def test_customer_mode_poster_no_chip() -> None:
    """客户向：poster_no 显示海报编号金标，listing_id 不出现；分数不出现。"""
    sys.path.insert(0, str(SCRIPTS))
    from listing_detail_poster import build_html

    payload = {**DEMO_PAYLOAD, "show_listing_id": False, "poster_no": "03"}
    html = build_html(payload, theme="dark")
    assert "海报编号 03" in html
    assert "TEST0001" not in html, "客户向不应显示房源编号"
    assert "★92" not in html, "客户向不应显示分数"
    assert "推荐" in html, "score_label 仍应作为档位 chip"
