---
name: baidu-lbs
description: Use for 百度地图LBS API：地址核对、POI检索、坐标转换、路线、天气、静态图。
version: 1.0.0
author: hermes
license: MIT
metadata:
  hermes:
    tags: [baidu, lbs, geocoding, maps, real-estate]
    related_skills: []
---

# 百度地图 LBS Web API

## When to Use

- 核对/解析物业地址（用户给地址或坐标，需要验证与官方地理数据是否一致）
- 城市、区域、商圈理解（行政区归属、adcode、周边）
- 楼盘/POI 查证、通勤距离测算、天气查询
- 需要地图截图插图（PPT/报告）
- 跨平台坐标比对（高德/腾讯/GPS 与百度坐标互转）

用户提供 AK（服务端密钥）：`<REDACTED_BAIDU_AK>`（2026-08-13 由用户提供）。

## ⭐ 首选通道：百度官方 MCP Server（已接入 Hermes，2026-08-14）

**这是绕过配额问题的通道——实测地理编码/地点检索/行政区划全部可用**（直连 WebAPI 返回空的那些服务，走 MCP 全通）。

- Streamable HTTP: `https://mcp.map.baidu.com/mcp?ak=<AK>`；SSE: `https://mcp.map.baidu.com/sse?ak=<AK>`
- 已在 Hermes 注册为 `baidu-maps`，工具前缀 `mcp_baidu_maps_*`（如 `mcp_baidu_maps_map_geocode`），**新会话生效**
- 14 个工具：map_geocode(地理编码)、map_reverse_geocode(逆地理)、map_search_places(地点检索)、map_place_details(详情)、map_directions(路线规划)、map_directions_matrix(批量算路)、map_weather(天气)、map_ip_location(IP定位)、map_road_traffic(路况)、map_search_pro(多维检索)、map_district_search(行政区划)、map_uri(地图调起)、map_mark(旅游规划图)、map_geoconv(坐标转换)
- 手动调用测试脚本模式：`python -c` + mcp SDK（sse_client / streamablehttp_client），见 mcp_sdk_test.py 思路；AK 放 URL 里即可，无需额外认证
- 注意：map_weather 的入参是 district/location/district_id，不是 region；map_search_places 支持 query+region 或 query+location+radius
- 已知验证数据：双林中横路8号=104.113310,30.656179（门址级，comprehension=100）；"金茂晓棠"的 POI 实际叫「东城金茂晓棠」（龙泉驿区大面街道，uid=edfe456d496bc4b32cb96dff）——注意与用户口头说的"城西金茂晓棠"名称/位置可能不一致，需向用户核实

## Agent Plan 通道（baidu-ai-map skill，SK 凭证，2026-08-14 接入）

- skill 位置：`skills/baidu-ai-map/`（clawhub 安装），凭证 `BAIDU_MAP_AUTH_TOKEN` 已持久化到 hermes .env（sk-ap- 开头，不回显）
- Base URL `https://api.map.baidu.com/agent_plan/v1/*`，统一 Header 鉴权 `Authorization: Bearer $BAIDU_MAP_AUTH_TOKEN`
- 端点：place（语义化AI检索，user_raw_request 必须保留原句+约束词）、direction（语义路线，澄清流程 answer_type=gptmodel_poi_clarify 需 refer_pois 消歧）、geocoding、reverse_geocoding、weather（**region 参数要传区县名或用 location**，传市级名会报错）、MapRender（resource_key → https://lbs.baidu.com/mapstatic/agentui_resource.html?resource_key=...）
- 坐标系统一 gcj02，坐标至少 6 位小数，禁止编造坐标
- 实测（2026-08-14）：place ✅ / reverse_geocoding ✅ / weather(location) ✅ / geocoding ❌（同账号配额问题）——与 MCP/WebAPI 一致，geocoding 服务在该账号下无数据

## 与 CRM 房源查询 MCP 的分工（2026-08-14）

**百度 MCP = 地理层（不做房源查询）；CRM MCP（crm-connector）= 房源层（不做地理计算）。协作不替代。**

| 能力 | CRM MCP（sale_map_/rental_map_） | 百度 MCP |
|---|---|---|
| 房源数据（挂牌/价格/户型/带看/维护人） | ✅ 唯一来源 | ❌ 无 |
| 地图选房（地点→半径→真实房源） | ✅ map_suggest + map_nearby_search（社区质心粒度，覆盖=贝壳有数据区域，最多100社区） | ❌ |
| 坐标互转/地址解析（门址级） | ❌ | ✅ map_geocode / map_reverse_geocode |
| 周边配套 POI（地铁/学校/商场） | ❌ | ✅ map_search_places（location+radius 圆形检索） |
| 通勤时间（驾车/公交/骑行/步行） | ❌ | ✅ map_directions（model=driving/transit/riding/walking） |
| 行政区划/边界 | ❌ | ✅ map_district_search |
| 路况/天气 | ❌ | ✅ map_road_traffic / map_weather |

**协作工作流**：百度先出地理事实（坐标、通勤、配套、区划）→ CRM 再搜真实房源。例：用户要"地铁2号线惠王陵站步行10分钟内、总价200万"→ 百度查地铁站坐标+步行算距 → CRM sale_map_nearby_search 以可达半径为圈搜房；营销名 vs POI 名核对（金茂晓棠→东城金茂晓棠）→ CRM sale_community_suggest 解析真实社区。

**坐标格式坑（实测踩过）**：百度 **MCP 工具坐标一律 lat,lng（纬度在前）**；WebAPI 直连的静态图/路线是 lng,lat，逆地理 location 是 lat,lng。传反会报 "No results found for origin" 或空结果。

## 控制台服务开通清单（用户截图 2026-08-14）

**已勾选（基础服务，蓝√）**：云存储、路线规划、鹰眼轨迹、轨迹纠偏API、骑行路线规划(轻量)、地理编码、国内天气查询、物流激活码平台、逆地理编码智能体、MCP(SSE)、行政区划热点POI查询、个性化室内图、直线测距API工具、地点检索、静态图、批量算路、实时路况查询、步行路线规划(轻量)、逆地理编码、海外天气查询、小客车标准导航API、巡航API、多维检索、定位问题反馈工具、未来驾车出行、步行路线规划、普通IP定位、坐标转换、时区、驾车路线规划(轻量)、公交路线规划(轻量)、轨迹重合分析API、行政区划检索API、公交路线规划API、小客车算路API、深度检索、公交信息查询、沿途搜API、骑行路线规划。

**高级服务（灰X，未开通，需付费/授权）**：全景静态图API、境外地点检索/地理编码/路线规划、逆地理编码境外POI、地址解析聚合、摩托车路线规划/批量算路、货车ETC/路线规划/批量算路、小客车收费、金融特征、AI向导、违章停车判别API、风险控制模型、智能硬件定位、智能调度、道路信息API、驾车价格预估、地址一致性判别API、红绿灯服务、websocket长连接、POI智能提取、定制瓦片服务、新停车OpenAPI、推荐上车点、行程分享、城乡类型判别、行驶里程分析、区域边界检索API、小客车路线还原、地图数据服务、AOI检索、沿途搜、导航诱导信息API、物流路网计算、路线库、红绿灯SDK定制接口、等时圈、等距圈、境外多语言版系列、车图导航/巡航、驾图系列数据、国际逆地理编码/智能硬件定位、国内逆地理编码。→ 这些接口调不通是正常的，别当成故障；需要时告知用户付费开通。

**注意：已勾选 ≠ 有配额**。2026-08-14 重测，地理编码/地点检索/行政区划虽已勾选仍返回空（status 0 空结果 / status 1 无相关结果 / status 8）。正确检查位置是控制台「配额管理」页的**每日配额数字**和**账号实名认证状态**：配额为 0 或未认证时就是这种"通了但没数据"的表现。用前先探测 `geocoding`；仍空则让用户去配额管理页看这几项的配额数。

## 实测服务可用性（2026-08-13/14 验证）

| 服务 | 状态 |
|---|---|
| 逆地理编码 reverse_geocoding/v3 | ✅ 正常（返回完整 addressComponent） |
| 路线规划 directionlite/v1（驾车/步行/骑行/公交） | ✅ 正常 |
| 坐标转换 geoconv | ✅ 正常 |
| 天气 weather/v1 | ✅ 正常 |
| 静态图 staticimage/v2 | ✅ 正常（返回 PNG） |
| 地理编码 geocoding/v3 | ❌ 返回 `status:1 "无相关结果"`（连官方示例地址都失败） |
| 地点检索 place/v2、place/v3 | ❌ `status:0` 但 `results:[]`（查"酒店/成都"都空） |
| 地点输入提示 suggestion | ❌ `status:8 "Parse Proto Failure"` |
| 行政区划 api_region_search/v1 | ❌ `status:0` 但 `districts:[]` |

**诊断结论：AK 本身有效（不是 101/102 错误），服务开关已勾选但接口返回空——典型是配额数为 0 或账号未完成实名认证**。典型表现就是 status 0 但空结果 / status 1 无相关结果 / Parse Proto Failure——不要把空结果当成"查无此地"。用户需在 https://lbsyun.baidu.com/apiconsole/ 配额管理页确认「地理编码、地点检索、行政区划」的每日配额 >0（0 则点提升配额/完成认证）。开通后我重测，通了再继续；仍空则明确告知用户，不要猜测结果。

## 通用规则

- 所有输出坐标默认 **bd09ll**（百度经纬度）。高德/腾讯=gcj02，GPS=wgs84。混用会偏几百米，跨平台比对前必须用 geoconv 转换。
- 逆地理编码 location 参数是 `lat,lng`；路线规划 origin/destination 是 `lat,lng`；静态图 center 是 `lng,lat`。注意顺序！
- 接口失败先看 status：0=ok；1=内部错误/无相关结果；8=Parse Proto Failure；101=ak非法；102=MCODE非法；111=当日配额超限；201=权限不足/APP类型错；211=IP白名单校验失败；302=天配额超限；401=并发超限；402=服务被禁用（控制台开通）。
- 中文参数必须 URL 编码（curl 直接传中文通常可以，浏览器/代码里要 encodeURIComponent）。

## 端点速查（GET，output=json&ak=...）

```bash
AK=<REDACTED_BAIDU_AK>
# 地理编码（结构化地址→坐标，address≤128字节，city 过滤歧义；结果带 precise/comprehension(0-100)/confidence 判精度）
curl "https://api.map.baidu.com/geocoding/v3/?address=成都市双林中横路8号&city=成都市&ak=$AK&output=json"
# 逆地理编码（坐标→地址，coordtype 默认 bd09ll；extensions_poi=1 返回周边POI，poi_types=酒店 可过滤）
curl "https://api.map.baidu.com/reverse_geocoding/v3/?location=30.657,104.067&ak=$AK&output=json"
# 地点检索 v3：区域 region / 圆形 around / 多边形 polygon / 详情 detail / 提示 suggestion
curl "https://api.map.baidu.com/place/v3/region?query=金茂晓棠&region=成都市&region_limit=true&ak=$AK&output=json"
curl "https://api.map.baidu.com/place/v3/detail?uid=<POI_ID>&ak=$AK&output=json"
# 地点检索 v2（旧版，仍可用）：place/v2/search 参数 query/region/tag/bounds/location+radius/page_num/page_size/scope
# 行政区划（keyword=区划名或adcode，sub_admin=0-3 下级级数，extensions_code=1 国标编码，extensions_polygon=0/1/2 边界）
curl "https://api.map.baidu.com/api_region_search/v1/?keyword=成都市&sub_admin=1&ak=$AK"
# 坐标转换 v2（type 单一参数：1 amap/tencent→bd09ll；2 gps→bd09ll；3 bd09ll→bd09mc；4 bd09mc→bd09ll；5 bd09ll→amap/tencent；6 bd09mc→amap/tencent。批量≤100坐标，法律上不支持转回 GPS）
curl "https://api.map.baidu.com/geoconv/v2/?coords=104.07,30.66&type=2&ak=$AK"
# 旧版 geoconv/v1 仍可用：from/to（1 GPS, 2 搜狗, 3 gcj02, 5 bd09mc 等），from=3&to=5 = 高德→百度
# 路线规划（tactics=0 智能推荐；返回 distance 米 / duration 秒 / steps；公交 transit 有票价）
curl "https://api.map.baidu.com/directionlite/v1/driving?origin=30.65,104.07&destination=30.70,104.13&ak=$AK"
# 天气（district_id=adcode 或 location；data_type=now/fc/index/alert/all）
curl "https://api.map.baidu.com/weather/v1/?district_id=510100&data_type=all&ak=$AK"
# IP定位（coor=bd09ll|gcj02ll）
curl "https://api.map.baidu.com/location/ip?ip=110.184.0.1&ak=$AK"
# 静态地图图（center=lng,lat；width/height/zoom；markers 可标点；用于PPT/报告插图）
curl "https://api.map.baidu.com/staticimage/v2?center=104.066882,30.657461&width=600&height=400&zoom=15&ak=$AK"
# 地址识别（从文本提取结构化地址）POST https://api.map.baidu.com/api_recog_address/v1/recog
# 地址解析聚合（批量地址解析）https://api.map.baidu.com/address_analyzer/v2
```

## 房产场景工作流

1. **核对物业地址**：有坐标 → 逆地理编码，比对返回的 formatted_address / addressComponent 与用户给的地址是否一致（区、街道、门牌）。有地址文字 → 地理编码，看 comprehension（≥80 才可靠）和 precise（1=精确打点）。两者都有 → 双向核对。
2. **新盘/楼盘查证**（如城西金茂晓棠）：先 place/v3/suggestion 或 region 搜楼盘名；新盘 POI 常缺失，退路是地理编码查"XX楼盘"或售楼处路名，再逆地理拿区划归属。POI 库里没有 ≠ 楼盘不存在，明说这一点。
3. **城市地域理解**：逆地理的 `business`（商圈，如"汪家拐,南大街"）、addressComponent.adcode 定位行政归属；行政区划 API 拿区/街道边界。
4. **通勤/区位价值**：directionlite driving 算驾车距离时长，transit 算公交地铁（注意返回时间不含等车）。
5. **PPT 地图配图**：staticimage/v2 配 markers 标注楼盘位置，输出 PNG 直接进文档。

## 环境陷阱

- 本机 bash /tmp 及 ~ 下 curl -o 落盘不可靠（文件写后消失，疑似安全软件拦截）。要保存二进制文件时：`curl ... | python -c "import sys;open(r'C:\...', 'wb').write(sys.stdin.buffer.read())"` 让 python 写，或用 write_file 间接落盘。验证用 `curl ... | python -c "import sys; d=sys.stdin.buffer.read(); print(len(d), d[:8])"`。
- 官方文档中心（lbsyun.baidu.com/docs/webapi?title=...）是 SPA，curl 直接抓是空壳；正文在 `mapopen-docs-assets.bj.bcebos.com/docs_output/webapi/topic-<hash>.chunk.js`，需带 Referer 头才能下载。文档路径枚举见 faq/api?title=webapi 页面源码。
- 老 wiki 路径 lbsyun.baidu.com/index.php?title=webapi/... 会 302 到新版文档中心，curl 需 -L。
