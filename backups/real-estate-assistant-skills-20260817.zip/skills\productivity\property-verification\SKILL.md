---
name: property-verification
description: Use when user asks 查档/查抵押/产权核验 - 蓉e办 verify + screenshots.
version: 1.0.0
author: hermes
license: proprietary
metadata:
  hermes:
    tags: [real-estate, chengdu, verification, property]
    related_skills: [rental-search, sale-search, crm-connector-ops]
---

# Property verification (房产证查档)

Use the `property-verification` MCP tools. No browser needed. The service parses the certificate server-side and queries 蓉e办 official records.

## When to use

User provides a property certificate photo (WeChat images land in `~/AppData/Local/hermes/cache/images/`) or a local file path, and asks to 查档 / 查抵押查封 / 产权核验.

## Workflow

1. **Verify the image file first**: exists, JPG/PNG, ≤10MB (terminal `file` or PIL). The user's vision model often cannot read images — **do NOT gate on vision_analyze**; the service parses the certificate server-side, so submit directly once the file checks out.
2. **`pv_verify_submit`** with absolute `image_path` → `job_id`, `status: running`, `remaining_minute` hint.
3. **Poll `pv_verify_status`** every ~10–15 s until `status: succeeded` (typically ~25 s, but can stretch to ~1.5–3 min when the server-side model retries — keep polling; don't give up early). Pitfall: `result` may be fully populated while status is still `running` — keep polling; artifacts are only generated at `succeeded`.
4. **`pv_verify_result`** returns the official table as `headers` / `row` / `fields`. Fields observed: 业务件号, 产权证号, 区域, 街道, 门牌号/附号, 栋号, 单元号, 楼层号, 房间号, 套内面积, 公摊面积, 房屋用途, **是否抵押**, **是否查封**. The tool does NOT summarize — draw the conclusions yourself.
5. **Download artifacts** via `pv_verify_download` (spec=`panel` 查档结果区域截图, `full` 整页截图, `zip` 全部打包) → local temp paths. Deliver panel + full to the user with `MEDIA:<path>`.
6. **Privacy cleanup**: delete the local copy of the user's certificate photo after verification completes (证件图片属敏感个人信息). Tell the user you did so.
7. **`pv_verify_share_link`** (job_id, spec, ttl 10–604800 s) only when the user needs a shareable URL to forward elsewhere: short-lived signed link over plaintext HTTP — never re-forward to third parties.

`pv_verify_stats` (served count) is a quick liveness check before starting.

## Reporting style

Present plainly: 产权证号, 坐落 (区域/街道/栋/单元/楼层/房间), 面积, 用途, then highlight 是否抵押 and 是否查封. Flag practical implications (e.g. 已抵押 → 交易/签约前需确认解押安排). Keep it concise — the user is a real-estate professional.

**Cross-check photo vs official data**: compare the address fields read from the certificate photo (栋/单元/楼层/房间) against the official 蓉e办 row. If they differ (observed: photo read 6层9号, official returned 楼层5/房间9), state the discrepancy explicitly and recommend manual verification — conclusion follows official data, but the mismatch itself is valuable signal (OCR misread or wrong unit).

## Pitfalls

- vision_analyze failing on the photo is NOT a blocker — the service parses server-side; only check file format/size locally.
- `result` populated while status=running: wait for `succeeded` before claiming completion or downloading artifacts.
- Submit only clear, unobstructed photos; JPG/PNG ≤10MB.
- The original uploaded image should be deleted after the job finishes (privacy requirement).
