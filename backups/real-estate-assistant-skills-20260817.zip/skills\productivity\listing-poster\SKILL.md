---
name: listing-poster
description: 房源推荐海报生成（HTML/CSS+Playwright 渲染，dark 主题编号拼图交付，v5 客户向重设计）。
version: 2.0.0
author: hermes-curator
license: proprietary
metadata:
  hermes:
    tags: [crm, beike, poster, image, 房源图片拼接]
    related_skills: [listing-screening, crm-connector-ops, rental-search, sale-search]
---

# 房源海报/拼图生成（listing-poster）

## When to Use

- 用户要求把筛选出的房源做成一张图（推荐海报、编号拼图、联系表、房源图册）。
- 筛选/推荐流程要交付"编号拼图"（用户报号即取详情）时，一律用本技能。
- 旧模板 make_recommend_sheet.py 不再用于推荐交付（用户 2026-08-14 明确：新模板好看，dark 版定稿）。
- **v5（2026-08-15 用户定稿整版替换）**：卡片信息权重重排（小区名左主位 + 价格右上）、评分徽章去分数、TOP1-3 金框动线、✦卖点行；详情图改 hero 封面 + 8 格生活规格 + 两列实勘网格，且**内部字段（维护门店/来源/等级/带看）一律不渲染**。

## 模板位置与运行环境

- **模板脚本（skill 内维护，单一来源）**：本技能目录 `scripts\listing_poster.py`（**即 v5 定稿版**，2026-08-15 整版替换）+ `scripts\listing_detail_poster.py`（详情长图 v5）——**脚本必须放在 skill 自己目录下**（2026-08-14 用户规范要求），vswp 项目内旧副本勿再引用。
- **运行解释器**：`C:\Python313\python.exe`（已装 playwright 1.58 + chromium；**Hermes venv 没有 playwright，勿用**）。
- 输出默认 `C:\Users\shipi\AppData\Local\hermes\skills\productivity\listing-poster\outputs\listing_poster_<时间戳>\`（poster.png + poster.html + listing_map.json），可用 `--out` 指定（推荐显式 `--out` 到工作目录，方便交付）。

## 用法

```bash
cd ~/AppData/Local/hermes/skills/productivity/listing-poster
/c/Python313/python.exe scripts/listing_poster.py <payload.json> --theme dark [--out 输出目录]
# 或 stdin 输入
/c/Python313/python.exe scripts/listing_poster.py - --theme dark < <(cat payload.json)
```

常用参数：`--theme light|dark`（默认 light，**推荐交付用 dark**）、`--image-size 450|750|800|1500`（默认 750）、`--width`（视口宽，默认 1360）、`--scale`（导出倍率，默认 1；2x 仅大屏展示需要时手动开）。

**背景用纯色**（2026-08-14 定稿：渐变→纯色）。dark 背景 `#0d1526`（v5 微调加深，卡片不透明度提高以增强微信压缩后可读性），light 背景 `#eef2f7`。**blob 渐变光晕装饰已删除**。冒烟测试（skill 目录下）：`env -u PYTHONPATH C:/Python313/python.exe -m pytest scripts/tests/ -q`（16 项：海报渲染/纯色背景/像素级/卡片数/TOP 样式/编号映射/CDN 后缀 + 客户向纪律[无分数/无编号/note 内部词替换/卖点行] + 详情图渲染/hero 结构/8 格规格/内部字段不渲染/状态翻译/托管通道/客户向编号 chip）。若需进一步减小体积：降 `--image-size`（450 最大头）或 `--scale 1`。

**微信传输场景（用户 2026-08-14 澄清）**：交付图通过微信发给客户，**一律默认 `--scale 1`**（两脚本默认值已改）——微信会压缩图片，2x 无意义且体积约 3 倍（20.3MB→7.4MB 实测）。`--scale 2` 仅大屏展示需要时手动开。

## payload 结构

```json
{
  "title": "万象城商圈 房源精选",
  "subtitle": "套一 · 1000-2500元",
  "note": "数据来源：贝壳平台",
  "theme": "dark",
  "show_listing_id": false,
  "items": [ ...房源字典数组... ]
}
```

**note 是页脚说明，客户向海报（微信交付）禁止出现内部字样**（内网/A+ 内网/门店/维护人/房管电话）——统一写"数据来源：贝壳平台"；`show_listing_id` 默认 false 同理（房源编号是 CRM 内部标识，仅内部交接时置 true）。**v5 起脚本自带兜底**：客户向（show_listing_id=false）note 命中内部词（A+/内网/门店/维护人/房管电话）时整体替换为"数据来源：贝壳平台"并打印警告；内部交接模式保留原文。

**items 直接塞 MCP 返回的原始行即可，脚本自动归一化，无需手工转字段**：

1. 租赁列表行：`{listing_id, community, layout, area_sqm, monthly_rent_yuan, orientation, title_image_url, floor_plan_image_url, ...}`
2. 买卖列表行：`{listing_id, community, biz_circle, layout, area_sqm, total_price_text, total_price_yuan, unit_price_yuan_per_sqm, floor_desc, orientation, tags, quality_score, surface_image_url, floor_plan_image_url, ...}`
3. 地图附近房源行：`{listing_id, title, description, tags, price_text, unit_price_text}`（小区名/户型/面积自动从 title 正则截取）

统一覆盖字段（优先级最高）：`community / layout / area_text / orientation / floor_text / price_primary / price_unit / price_sub / score / score_label / tags / type_label / image_url / caption / highlight`。

## 卡片版式（v5 定稿，固定）

- **每行 3 个房源**，卡片等高；**TOP 1-3 金色边框 + 金色编号角标**（浏览动线锚点），第 1 名右上角另加 TOP 1 金标。
- 图片区：实勘封面（4:3，object-fit cover），左上角玻璃角标编号 01..n（报号用，前三名金底）；图片来自 title_image_url / surface_image_url，缺图自动占位。
- 信息区四排（v5 信息权重：小区名与价格是扫图两大锚点，同排分置左右）：
  - ① **小区名（左主位，16px 粗体，超长省略）+ 价格（右上，租赁红/买卖青 22px）**；买卖单价作为价格下方 11px 小字。
  - ② 户型|面积|朝向|楼层 灰条。
  - ③ 类型标签（最左）→ 特色标签（≤3）→ 档位徽章（右）。
  - ④ **✦ 一句话卖点行**（11.5px，自动生成：低价租金/低于板块分位/随时入住/民水民电/精装/朝向采光；`highlight` 字段覆盖；无信号则不渲染）。
- **类型标签（2026-08-14 用户定稿）**：第三排最左 chip（不是图片角标！），`del_type`/`delType`：2→**普租**蓝底白字，5→**托管**紫底白字，必须显示、不允许缺失（无 del_type 时留空，不猜）；`type_label` 可覆盖。
- **特色标签纪律**：单行不换行，超出宽度整颗隐藏，**最多渲染 3 个**（v5 硬上限，取代旧像素预算估算）。
- **档位徽章去分数化（v5）**：客户向只显示档位文案，≥88"精选"（青）/ ≥78"优选"（金）/ 低于 78 不显示；`score_label` 可覆盖文案。**分数（含 >100 的视觉修正叠加值）客户向一律不出现**；show_listing_id=true 内部交接模式徽章才带 `★分数`。
- 页眉右侧："共 N 套 · 按综合性价比排序" + "看中哪套，回复编号即可看详情"；页脚 CTA："回复编号 01-N，立即发您该套详情与全屋实勘"。
- 图片下载：img.ljcdn.com 原图直接请求 403，自动剥 `!` 指令后拼公开尺寸后缀 `.750x.jpg` 等（无需 cookie）；下载失败自动换占位图，不中断整批。

## 筛选推送流程集成（编号拼图交付）

1. 候选房源列表（筛选打分完成后）**按 score 降序** 排列。
2. 构造 payload：`items` = 排序后的原始 MCP 行（保留 listing_id 作对照表）；`title` = 筛选条件描述；`subtitle` = 价格段/户型等；`theme` = **dark**。
3. 渲染 PNG → 交付给用户，同时输出目录自动生成 **`listing_map.json`（编号↔房源映射）**——`no` = 卡片角标编号（01..n），与渲染顺序一致，含 `listing_id` 及原始行全字段。
4. 交付时附**编号 ↔ 房源对照**（编号与排序一致）；**报号匹配必须查 `listing_map.json`**（`no` → `listing_id`），禁止用小区名/价格等展示字段二次匹配（同小区同价易错配）。
5. 用户报编号 → 见下方"报号详情流程"。

## 报号详情流程（v5：hero 封面 + 8 格生活规格 + 两列实勘网格）

用户报编号后，生成**该房源的详细信息 + 全部实勘照片 + 户型图的竖向长图**：

1. 从海报输出目录读 `listing_map.json`，按 `no` 取 `listing_id`（**唯一可靠匹配**）。
2. 调 `rental_listing_get_detail(listing_id)` 拿详情 + `rental_listing_get_prospect(listing_id)` 拿全屋实勘（photos[]: url/room_name/image_type TITLE封面或REAL/upload_user/created_at + floor_plan_url 户型图）；**另调 `rental_listing_get_house_info` 提取生活规格**（见第 3 条字段表）。
3. 构造 payload（detail + prospect 原样塞入 + 生活规格字段 + `poster_no`）→ 跑本技能 `scripts\listing_detail_poster.py`：
   `/c/Python313/python.exe scripts/listing_detail_poster.py <payload.json> --image-size 750 --out <dir>`（在 skill 目录下执行）
   - **v5 竖向结构**：封面 hero 大图（底部渐变叠加小区名/户型摘要/价格大字 + `poster_no` 金色"海报编号 N"角标——客户侧标识，替代内部 listing_id）→ **8 格规格卡**（户型/面积/朝向/楼层 + **电梯/入住/水电气/看房**）→ 客户向 chips（状态[有效→在租]/新上/省心租房管/特色标签）→ **其余实勘照片两列网格**（房间名 + 拍摄日期玻璃角标，长图比逐张竖排缩短约一半）→ **户型图全宽收尾** → 页脚 CTA"满意可约实地看房"
   - **生活规格字段（agent 从 house_info 提取后塞 detail）**：`elevator`（property_info.elevator）、`live_time`（maintain 可入住时间）、`utility`（water_type=民水 + electric_type=民电 → "民水民电"）、`viewing`（has_key → "有钥匙 · 随时可看"）。脚本对 water_type/electric_type/can_live_time/key_desc 有自动兜底映射，缺失一律显示"—"，不猜。
   - **内部字段一律不渲染（v5 合规定稿）**：维护门店/来源/房屋等级/带看次数不再出现在详情图（旧版 chips 是合规漏洞）；评分不显示分数（含 >100 视觉修正值），`score_label` 作为 hero 档位 chip。`show_listing_id: true` 内部模式才显示房源编号与分数。
   - dark 主题默认；两列网格场景 `--image-size 750` 即可（默认 1500 供单列高清需要）；输出 `detail.png`
    - **托管房源（del_type=5）改走托管通道**（2026-08-15 接入）：`tuoguan_listing_get_detail(cell_code)` 原样塞 payload 的 `tuoguan` 键——脚本自动映射（实勘照片按 primary_flag 封面进 hero、house_type_images 全部户型图收尾、房管→"省心租房管"chip、钥匙/可入住→看房/入住规格、指导租金），不要再传 detail/prospect 普租键。`listing_map.json` 的 `listing_id` 是 house_del_code，不是 cell_code；主路径用 `GET /api/v1/listings/rental/{listing_id}/redirect`（连接器封装的前端点击链路 getRedirectUrl）取 cell_code，再以详情返回的 house_del_code 回链确认；无跳转时再查 `tuoguan_listing_search` 待出租库存候选兜底，或向用户要托管详情页 URL（末段即 cell_code）。
4. **跟进记录永不获取、永不展示**（get_follows 不碰）；详情输出不含业主联系方式/底价/密码字段。
5. **买卖无 prospect 接口**（sale 域无实勘数组）——买卖详情图用列表行封面+户型图兜底（hero 用封面，网格区无图时隐藏实勘区）；托管已由第 3 条托管通道解决。

## 托管房源（delType=5）拿图片的正确姿势（2026-08-15 更新）

1. **详情/全屋实勘走 `tuoguan_listing_get_detail(cell_code)`**（2026-08-15 接入，连接器已部署）——`prospects[]` 返回全部实勘照片（按房间 name 标注 + primary_flag 封面 + create_time），`house_type_images[]` 户型图，`vr_url` VR 链接。主路径用 `GET /api/v1/listings/rental/{listing_id}/redirect` 取 cell_code，并确认详情返回的 house_del_code 等于列表 listing_id；确认失败不得用封面+户型图替代全屋实勘。详情图 payload 用 `tuoguan` 键原样塞入（见上方报号详情流程第 3 条）。不要再调 `rental_listing_get_prospect`（托管 ids 在普租域恒空，非报错）。
2. **列表海报/封面仍用 rental_listing_search 列表行字段**：`title_image_url` → 封面图；`floor_plan_image_url` → 户型图（列表行是列表卡片的唯一形态，tuoguan 详情 dict 不是列表行，勿塞 items）。
3. **下载规则（按 URL 路径分桶）**：
   - URL 含 **lease-image**：原图直连 200，无需任何 cookie/referer/后缀（托管实勘照片多在此桶）。多数带右下角小半透明"链家"logo，个别无水印，需逐张目视确认。
   - URL 含 **110000-inspection 或 hdic-frame**：原图恒 403（登录态也无效）。剥掉 URL 尾部 `!` 及其后全部内容（若有），再拼尺寸后缀即 200：`.450x.jpg`（缩略）/ `.750x.jpg` / `.1500x.jpg`（高清）。这类变体必带链家水印。
   - 带 `!m_fit,...` / `!m_fill,...` 完整指令的 URL：原样请求即 200（页面自己的公开变体，带水印）；或剥指令拼尺寸后缀取更大图。**两个渲染脚本已内置自动剥离**（2026-08-15），手工拼 URL 时才需注意。

## 用 / 参数速查

## Pitfalls

- **Hermes venv 无 playwright**：`python` 直接跑会 `ModuleNotFoundError`，必须用 `C:/Python313/python.exe`。
- 输出目录的 `poster.html` 保留用于调试；交付用 `poster.png`（`--scale` 默认 1，微信场景够用）。
- 图片下载失败只影响单卡（占位图），不会报错中断——若占位图多，检查 URL 是否带 `!` 畸形指令（脚本已自动剥离 `!` 后再拼后缀，2026-08-15 起；手工下载仍需自行剥）；**连续批量下载可能触发 CDN 短时 TLS 拒连（代理切换也会），等 1-2 分钟重跑即恢复**（2026-08-15 实测）。
- 页脚自动附"生成于 <时间>"，note 字段写数据来源（客户向用"贝壳平台"，禁内部字样；v5 脚本对客户向 note 有内部词自动替换兜底）。
- 详情图生活规格（电梯/入住/水电气/看房）靠 agent 从 house_info 提取塞 detail——不提取时显示"—"（合法，不算错误）。
