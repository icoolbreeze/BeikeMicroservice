# Real-estate assistant skills backup

- Source: `C:/Users/shipi/AppData/Local/hermes/skills`
- This archive is a backup snapshot, not the active Hermes skill source.
- Cache files, credentials, cookies, environment files, and Python bytecode were excluded.
- The Baidu AK in `baidu-lbs/SKILL.md` was redacted in this backup.
- Restore by extracting back to the Hermes skills directory only after reviewing the manifest and local changes.
