# -*- coding: utf-8 -*-
"""房源图片拼图模板：公开下载水印图（无需 cookie）并拼成一张标注大图。

用法：
1. 从 listing search 结果收集 (listing_id, 价格, 户型, 面积, 朝向,
   title_image_url/surface_image_url, floor_plan_image_url) 填入 LISTINGS。
2. 运行：env -u PYTHONPATH C:/ProgramData/miniconda3/python.exe make_listing_sheet.py
   输出 images/<name>.jpg，用 MEDIA:<绝对路径> 发送。

关键：img.ljcdn.com 的水印缩放变体是公开的——剥掉 URL 尾部残缺指令
（如 !m_fill,l_dy），拼上 .720x540.jpg / .1500x.jpg 后缀即可无 cookie 下载。
"""
import os, io, urllib.request

BASE = "https://img.ljcdn.com"
OUT_NAME = "listings_sheet.jpg"  # 输出文件名

# (listing_id, 价格标签, 户型, 面积, 朝向, 实勘/封面URL, 户型图URL) — 替换为实际数据
LISTINGS = [
    # ("106128839942", "180万", "2室2厅", 83.85, "北",
    #  "https://img.ljcdn.com//110000-inspection/pc1_xxx.jpg!m_fill,l_dy",
    #  "https://img.ljcdn.com/hdic-frame/standard_xxx.jpeg"),
]


def public_url(url):
    """剥 ! 指令 → 规范化 → 拼公开缩放后缀（默认 .720x540.jpg，可换 .1500x.jpg）。"""
    if not url:
        return None
    url = url.split("!")[0]               # 剥掉残缺指令（!m_fill,l_dy 等，缺宽高会 400）
    url = url.replace("//110000-inspection", "/110000-inspection")
    if url.startswith("/"):
        url = BASE + url
    if not url.endswith(".720x540.jpg"):
        url = url + ".720x540.jpg"        # 公开水印版，无需 cookie
    return url


def download(url):
    url = public_url(url)
    if not url:
        return None
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            data = r.read()
            if len(data) < 500:           # <500B 视为无图/错误响应
                return None
            return io.BytesIO(data)
    except Exception as e:
        print(f"  DL-FAIL {url[-50:]} {e}")
        return None


def main():
    from PIL import Image, ImageDraw, ImageFont
    os.makedirs("images", exist_ok=True)
    CELL_W, CELL_H, label_h = 480, 380, 52
    COLS = 4
    n = len(LISTINGS)
    ROWS = (n + COLS - 1) // COLS
    W, H = COLS * CELL_W, ROWS * CELL_H + 60
    sheet = Image.new("RGB", (W, H), "#1a1a1a")
    draw = ImageDraw.Draw(sheet)
    font_l = ImageFont.truetype("C:/Windows/Fonts/msyhbd.ttc", 26)
    font_s = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 20)
    draw.text((20, 12), f"{OUT_NAME} · 共{n}套", font=font_l, fill="#ffd166")
    ok = 0
    # 排序键：价格标签为纯数字元/月 或 万 文本时需自行定义 key；默认按列表顺序
    for i, (lid, price, layout, area, orient, turl, furl) in enumerate(LISTINGS):
        col, row = i % COLS, i // COLS
        x, y = col * CELL_W, 60 + row * CELL_H
        img = download(turl) or download(furl)  # 实勘/封面优先，户型图兜底
        if img is None:
            draw.rectangle([x, y, x + CELL_W, y + CELL_H - label_h], fill="#2b2b2b")
            draw.text((x + 20, y + CELL_H // 2 - 20), "无图", font=font_s, fill="#888")
        else:
            im = Image.open(img).convert("RGB")
            iw, ih = im.size
            scale = max(CELL_W / iw, (CELL_H - label_h) / ih)
            im = im.resize((int(iw * scale) + 1, int(ih * scale) + 1))
            im = im.crop(((im.width - CELL_W) // 2, (im.height - (CELL_H - label_h)) // 2,
                          (im.width - CELL_W) // 2 + CELL_W, (im.height - (CELL_H - label_h)) // 2 + CELL_H - label_h))
            sheet.paste(im, (x, y))
            ok += 1
        draw.rectangle([x, y + CELL_H - label_h, x + CELL_W, y + CELL_H], fill="#0f0f0f")
        draw.text((x + 10, y + CELL_H - label_h + 4), f"{price} · {layout}", font=font_s, fill="#ffffff")
        draw.text((x + 10, y + CELL_H - 26), f"{area}㎡ {orient}  #{lid[-4:]}", font=font_s, fill="#9ecbff")
    out = f"images/{OUT_NAME}"
    sheet.save(out, quality=88)
    print(f"OK {ok}/{n} -> {out} ({os.path.getsize(out)//1024}KB)")


if __name__ == "__main__":
    main()
