"""
listing_poster.py v5 冒烟测试：真实渲染 + 纯色背景断言 + 客户向纪律。

运行（skill 目录，注意 PYTHONPATH 坑）：
    env -u PYTHONPATH C:/Python313/python.exe -m pytest scripts/tests/ -q
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent.parent
SCRIPTS = ROOT / "scripts"
POSTER = SCRIPTS / "listing_poster.py"
PY = Path(r"C:\Python313\python.exe")  # 唯一装了 playwright 的解释器

DEMO_PAYLOAD = {
    "title": "冒烟测试 房源精选",
    "subtitle": "2套 · 测试",
    "note": "测试数据",
    "theme": "dark",
    "show_listing_id": True,
    "items": [
        {
            "listing_id": "TEST0001",
            "community": "测试小区A",
            "layout": "1室1厅1卫",
            "area_sqm": 50.0,
            "monthly_rent_yuan": 1500,
            "orientation": "南",
            "score": 90,
            "tags": ["测试标签"],
            "image_url": None,  # 无图 → 占位图路径，不依赖网络
        },
        {
            "listing_id": "TEST0002",
            "community": "测试小区B",
            "layout": "2室1厅1卫",
            "area_sqm": 80.0,
            "monthly_rent_yuan": 2500,
            "orientation": "南北",
            "score": 75,
            "tags": [],
        },
    ],
}


@pytest.fixture()
def rendered(tmp_path: Path) -> Path:
    payload = tmp_path / "payload.json"
    payload.write_text(json.dumps(DEMO_PAYLOAD, ensure_ascii=False), encoding="utf-8")
    out = tmp_path / "out"
    proc = subprocess.run(
        [str(PY), str(POSTER), str(payload), "--theme", "dark", "--no-download", "--out", str(out)],
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert proc.returncode == 0, f"渲染失败:\n{proc.stdout}\n{proc.stderr}"
    return out


def test_png_and_html_generated(rendered: Path) -> None:
    png, html = rendered / "poster.png", rendered / "poster.html"
    assert png.exists() and png.stat().st_size > 10_000, "PNG 未生成或过小"
    assert html.exists() and html.stat().st_size > 5_000, "HTML 未生成或过小"


def test_dark_theme_flat_background(rendered: Path) -> None:
    """dark 主题背景必须是纯色 #0d1526（v5 定稿），无渐变装饰。"""
    html = (rendered / "poster.html").read_text(encoding="utf-8")
    assert "--bg: #0d1526" in html, "dark 背景不是纯色 #0d1526"
    assert "blob" not in html, "不应存在 blob 渐变装饰"


def test_png_background_pixels_flat(rendered: Path) -> None:
    """像素级断言：PNG 四角背景采样均为纯色 #0d1526。"""
    from PIL import Image  # 延迟导入，pytest 环境缺 PIL 时跳过

    img = Image.open(rendered / "poster.png").convert("RGB")
    w, h = img.size
    corners = [(8, 8), (w - 8, 8), (8, h - 8), (w - 8, h - 8)]
    for x, y in corners:
        assert img.getpixel((x, y)) == (13, 21, 38), f"背景非纯色 at ({x},{y})"


def test_two_cards_rendered(rendered: Path) -> None:
    """v5：TOP1-3 卡片带 top 类，其余普通类，前缀计数应得 2。"""
    html = (rendered / "poster.html").read_text(encoding="utf-8")
    assert html.count('class="house-card') == 2, "应渲染 2 张卡片"
    assert 'class="house-card top"' in html, "第 1 张卡应为 TOP 金边样式"
    assert "TEST0001" in html and "TEST0002" in html, "房源编号应出现在卡脚（内部模式）"


def test_listing_map_generated(rendered: Path) -> None:
    """编号映射必须落盘：no ↔ listing_id 与卡片渲染顺序一致（报号匹配依据）。"""
    mapping = json.loads((rendered / "listing_map.json").read_text(encoding="utf-8"))
    assert len(mapping) == 2, "映射应有 2 条"
    assert [m["no"] for m in mapping] == [1, 2], "编号应从 1 递增"
    assert [m["listing_id"] for m in mapping] == ["TEST0001", "TEST0002"]
    # 与海报渲染顺序一致性：HTML 里第一张卡片编号 01
    html = (rendered / "poster.html").read_text(encoding="utf-8")
    first_card = html[html.index('class="house-card'):]
    assert first_card.index("01") < first_card.index("TEST0001")  # 角标在编号前
    # 映射不应包含 base64 图片数据
    assert all("data:" not in json.dumps(m, ensure_ascii=False) for m in mapping)


def test_cdn_suffix_url_strips_instruction_fragment() -> None:
    """带 `!` 指令的 URL 必须先剥指令再拼尺寸后缀，否则组合形态 404。"""
    sys.path.insert(0, str(SCRIPTS))
    from listing_poster import cdn_suffix_url

    complete = ("https://img.ljcdn.com/lease-image/house/a.jpeg"
                "!m_fit,h_630,w_516,l_bk,f_jpg")
    assert cdn_suffix_url(complete) == (
        "https://img.ljcdn.com/lease-image/house/a.jpeg.750x.jpg"
    ), "完整指令应剥离后拼后缀"
    broken = "https://img.ljcdn.com/hdic-frame/a.jpg!m_fill,l_dy"
    assert cdn_suffix_url(broken, 1500) == (
        "https://img.ljcdn.com/hdic-frame/a.jpg.1500x.jpg"
    ), "残缺指令应剥离后拼后缀"
    plain = "https://img.ljcdn.com//110000-inspection/a.jpg"
    assert cdn_suffix_url(plain) == (
        "https://img.ljcdn.com//110000-inspection/a.jpg.750x.jpg"
    ), "裸 URL 行为不变"
    suffixed = "https://img.ljcdn.com/a.jpg.450x.jpg"
    assert cdn_suffix_url(suffixed) == suffixed, "已带尺寸后缀的不重复拼"
    foreign = "https://other.com/a.jpg"
    assert cdn_suffix_url(foreign) == foreign, "非 CDN 域名原样返回"


# --------------------------------------------------------------------------
# v5 客户向纪律（纯函数级，不启浏览器）
# --------------------------------------------------------------------------
def _build(payload: dict) -> str:
    sys.path.insert(0, str(SCRIPTS))
    from listing_poster import build_html

    return build_html(payload, theme="dark", show_listing_id=bool(payload.get("show_listing_id")))


def test_customer_mode_hides_score_number() -> None:
    """客户向档位徽章不带分数；内部模式才显示 ★分数。"""
    customer = _build({**DEMO_PAYLOAD, "show_listing_id": False})
    assert "精选" in customer, ">=88 分应有「精选」徽章"
    assert "★90" not in customer and "★ 90" not in customer, "客户向不应显示分数"
    assert "房源编号" not in customer, "客户向不应显示房源编号"
    internal = _build(DEMO_PAYLOAD)
    assert "★90" in internal, "内部模式徽章应带分数"


def test_customer_note_internal_words_replaced() -> None:
    """客户向 note 含内部字样 → 整体替换为统一来源文案；内部模式保留原文。"""
    payload = {**DEMO_PAYLOAD, "note": "数据来源：贝壳 A+ 内网"}
    customer = _build({**payload, "show_listing_id": False})
    assert "贝壳平台" in customer and "A+" not in customer and "内网" not in customer
    internal = _build(payload)  # show_listing_id=True
    assert "A+ 内网" in internal, "内部交接模式保留原 note"


def test_highlight_and_top3_gold() -> None:
    """卖点行自动生成 + TOP1 角标只给第 1 名。"""
    html = _build(DEMO_PAYLOAD)
    assert "TOP 1" in html and "TOP 2" not in html, "只有第 1 名有 TOP 角标"
    assert "月租仅1500元" in html, "低价租金应生成卖点"
    assert "row-highlight" in html
